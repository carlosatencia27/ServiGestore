"""Carga datos FICTICIOS de demostración (nombres, cédulas y placas inventados).

Uso:  py cargar_datos_ficticios.py
IMPORTANTE: ejecutar solo en una carpeta de prueba. Si la base de datos ya tiene
registros, el script no hace nada, para no mezclar datos de demostración con datos reales.
"""
from datetime import date, timedelta

from app import base_datos, config, vencimientos
from app.fechas import sumar_meses

TABLAS = ("licencias", "expediciones", "tramites", "seguros", "tecnomecanicas")


def main():
    con = base_datos.conectar()
    if sum(con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in TABLAS):
        print("La base de datos ya tiene registros. No se cargó nada.")
        return
    hoy = date.today()

    def lic(tabla, nombre, ced, tel, cat, cat2, realizada):
        venc = vencimientos.vencimiento_por_categorias(con, [cat, cat2], realizada)
        con.execute(f"INSERT INTO {tabla} (nombre, cedula, telefono, tipo, categoria, categoria2, "
                    "fecha_realizada, fecha_vencimiento) VALUES (?,?,?,?,?,?,?,?)",
                    (nombre, ced, tel, vencimientos.tipo_de_categoria(cat), cat, cat2 or "",
                     realizada.isoformat(), venc.isoformat()))

    def veh(tabla, nombre, ced, tel, placa, inicio, extra=None):
        venc = sumar_meses(inicio, 12)
        if tabla == "seguros":
            con.execute("INSERT INTO seguros (nombre, cedula, telefono, placa, tecnomecanica, fecha_inicio, "
                        "fecha_vencimiento) VALUES (?,?,?,?,?,?,?)",
                        (nombre, ced, tel, placa, extra or 0, inicio.isoformat(), venc.isoformat()))
        else:
            con.execute("INSERT INTO tecnomecanicas (nombre, cedula, telefono, placa, fecha_inicio, "
                        "fecha_vencimiento) VALUES (?,?,?,?,?,?)",
                        (nombre, ced, tel, placa, inicio.isoformat(), venc.isoformat()))

    # Licencias: una vencida, una por vencer y otras vigentes
    lic("licencias", "Cliente Prueba Uno", "1000000001", "3000000001", "C1", None, hoy.replace(year=hoy.year - 3) - timedelta(days=20))
    lic("licencias", "Cliente Prueba Dos", "1000000002", "3000000002", "C2", None, hoy.replace(year=hoy.year - 3) + timedelta(days=10))
    lic("licencias", "Cliente Prueba Tres", "1000000003", "3000000003", "B1", None, hoy - timedelta(days=400))
    lic("expediciones", "Cliente Prueba Cuatro", "1000000004", "3000000004", "A2", None, hoy - timedelta(days=30))
    lic("expediciones", "Cliente Prueba Cinco", "1000000005", "3000000005", "B1", "C1", hoy - timedelta(days=90))
    # Seguros y tecnomecánicas
    veh("seguros", "Cliente Prueba Uno", "1000000001", "3000000001", "AAA111", hoy - timedelta(days=350), 1)
    veh("seguros", "Cliente Prueba Seis", "1000000006", "3000000006", "BBB222", hoy - timedelta(days=100))
    veh("tecnomecanicas", "Cliente Prueba Dos", "1000000002", "3000000002", "CCC333", hoy - timedelta(days=380))
    veh("tecnomecanicas", "Cliente Prueba Siete", "1000000007", "3000000007", "DDD444", hoy - timedelta(days=60))
    # Trámites de los últimos meses
    for i, (placa, valor) in enumerate([("AAA111", 180000), ("BBB222", 95000), ("CCC333", 240000),
                                         ("DDD444", 120000), ("EEE555", 310000)]):
        con.execute("INSERT INTO tramites (nombre, cedula, telefono, placa, traspaso, fecha_entrega, valor) "
                    "VALUES (?,?,?,?,?,?,?)", (f"Cliente Prueba {i + 1}", f"100000000{i + 1}", "3000000000",
                                               placa, 1, (hoy - timedelta(days=i * 20)).isoformat(), valor))
    con.commit()
    print("Datos ficticios cargados en:", config.RUTA_DB)


if __name__ == "__main__":
    main()
