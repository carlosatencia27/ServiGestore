@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================
echo   Creando el programa (.exe) - espere unos minutos
echo ==============================================
py -m pip install customtkinter pillow pyinstaller
if errorlevel 1 goto error
py -m PyInstaller --noconfirm --onedir --windowed --name GestionTransito --collect-all customtkinter main.py
if errorlevel 1 goto error
copy /y LEEME.txt dist\GestionTransito\LEEME.txt >nul
echo.
echo LISTO. El programa quedo en:  dist\GestionTransito\GestionTransito.exe
echo Para llevarlo a otro PC copie la carpeta completa  dist\GestionTransito
pause
exit /b 0
:error
echo.
echo Algo fallo. Verifique que Python este instalado (marcando "Add python.exe to PATH") y que haya internet.
pause
exit /b 1
