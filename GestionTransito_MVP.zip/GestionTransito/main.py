"""Punto de entrada: python main.py (o el .exe creado con construir_exe.bat)."""
import os
import sys
import traceback


def main():
    try:
        from app.ui.principal import App
        App().mainloop()
    except Exception:
        from app import config
        os.makedirs(config.CARPETA_DATOS, exist_ok=True)
        with open(os.path.join(config.CARPETA_DATOS, "error.log"), "a", encoding="utf-8") as f:
            f.write(traceback.format_exc() + "\n")
        try:
            from tkinter import messagebox
            messagebox.showerror("Error", "Ocurrió un problema inesperado.\n"
                                          "Se guardó el detalle en datos\\error.log")
        except Exception:
            pass
        sys.exit(1)


if __name__ == "__main__":
    main()
