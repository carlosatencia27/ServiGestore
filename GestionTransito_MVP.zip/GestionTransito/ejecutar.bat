@echo off
rem Abre el programa sin crear el .exe (requiere Python instalado)
cd /d "%~dp0"
py -m pip install --quiet customtkinter pillow
py main.py
if errorlevel 1 pause
