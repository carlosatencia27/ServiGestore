"""Utilidades de fechas. En la base se guardan como AAAA-MM-DD; en pantalla DD/MM/AAAA."""
import calendar
from datetime import date, datetime


def de_iso(texto):
    return date.fromisoformat(texto) if texto else None


def formatear(texto_iso):
    d = de_iso(texto_iso)
    return d.strftime("%d/%m/%Y") if d else ""


def parsear(texto):
    """Convierte 'DD/MM/AAAA' (también acepta - o .) en date. Lanza ValueError si es inválida."""
    limpio = texto.strip().replace("-", "/").replace(".", "/")
    return datetime.strptime(limpio, "%d/%m/%Y").date()


def sumar_meses(fecha, meses):
    total = fecha.month - 1 + meses
    anio = fecha.year + total // 12
    mes = total % 12 + 1
    dia = min(fecha.day, calendar.monthrange(anio, mes)[1])
    return date(anio, mes, dia)


def sumar_anios(fecha, anios):
    return sumar_meses(fecha, anios * 12)


def texto_dias(n):
    return "1 día" if n == 1 else f"{n} días"


_DIAS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
_MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
          "septiembre", "octubre", "noviembre", "diciembre"]


def fecha_larga(d):
    """Ej.: 'miércoles 14 de octubre de 2026'."""
    return f"{_DIAS[d.weekday()]} {d.day} de {_MESES[d.month - 1]} de {d.year}"


MESES_CORTOS = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]


def humanizar_dias(n):
    """1 día, 12 días, 3 meses, 2 años (para textos cortos en pantalla)."""
    if n < 31:
        return texto_dias(n)
    if n < 365:
        m = round(n / 30)
        return "1 mes" if m == 1 else f"{m} meses"
    a = round(n / 365)
    return "1 año" if a == 1 else f"{a} años"
