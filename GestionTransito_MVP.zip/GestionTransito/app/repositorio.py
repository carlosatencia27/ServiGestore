"""Acceso a los datos: agregar, editar, eliminar y buscar."""
import sqlite3

from .base_datos import normalizar

CAMPOS_BUSQUEDA = ("nombre", "cedula", "placa")


class Repositorio:
    def __init__(self, con, tabla, columnas, derivar=None):
        self.con = con
        self.tabla = tabla
        self.columnas = list(columnas)
        # función opcional derivar(datos, previo) que completa datos (ej. fecha de vencimiento)
        self.derivar = derivar

    def _preparar(self, datos, previo=None):
        datos = dict(datos)
        if self.derivar:
            datos = self.derivar(datos, previo)
        return {k: v for k, v in datos.items() if k in self.columnas}

    def listar(self, texto=""):
        sql = f"SELECT * FROM {self.tabla}"
        params = []
        buscado = normalizar(texto.strip())
        if buscado:
            condiciones = [f"norm({c}) LIKE ?" for c in CAMPOS_BUSQUEDA if c in self.columnas]
            sql += " WHERE " + " OR ".join(condiciones)
            params = [f"%{buscado}%"] * len(condiciones)
        sql += " ORDER BY id DESC"
        return self.con.execute(sql, params).fetchall()

    def obtener(self, id_):
        return self.con.execute(f"SELECT * FROM {self.tabla} WHERE id = ?", (id_,)).fetchone()

    def insertar(self, datos):
        d = self._preparar(datos)
        cols = ", ".join(d)
        marcas = ", ".join(["?"] * len(d))
        cur = self.con.execute(f"INSERT INTO {self.tabla} ({cols}) VALUES ({marcas})", list(d.values()))
        self.con.commit()
        return cur.lastrowid

    def actualizar(self, id_, datos):
        previo = self.obtener(id_)
        d = self._preparar(datos, dict(previo) if previo else None)
        sets = ", ".join(f"{c} = ?" for c in d)
        self.con.execute(f"UPDATE {self.tabla} SET {sets} WHERE id = ?", list(d.values()) + [id_])
        self.con.commit()

    def eliminar(self, id_):
        self.con.execute(f"DELETE FROM {self.tabla} WHERE id = ?", (id_,))
        self.con.commit()


# ---------- Ajustes ----------
def obtener_ajuste(con, clave, defecto=None):
    fila = con.execute("SELECT valor FROM ajustes WHERE clave = ?", (clave,)).fetchone()
    return fila["valor"] if fila else defecto


def guardar_ajuste(con, clave, valor):
    con.execute("INSERT INTO ajustes (clave, valor) VALUES (?, ?) "
                "ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor", (clave, str(valor)))
    con.commit()


# ---------- Categorías de licencia (lista editable, con años de vigencia) ----------
TABLAS_LICENCIA = ("licencias", "expediciones")


def listar_categorias(con):
    return [f["codigo"] for f in con.execute("SELECT codigo FROM categorias ORDER BY codigo")]


def listar_categorias_detalle(con):
    return con.execute("SELECT codigo, anios FROM categorias ORDER BY codigo").fetchall()


def agregar_categoria(con, codigo, anios=10):
    codigo = codigo.strip().upper()
    if not codigo:
        raise ValueError("Escriba el nombre de la categoría.")
    try:
        con.execute("INSERT INTO categorias (codigo, anios) VALUES (?, ?)", (codigo, int(anios)))
        con.commit()
    except sqlite3.IntegrityError:
        raise ValueError(f"La categoría {codigo} ya existe.")


def editar_categoria(con, viejo, nuevo, anios):
    """Cambia el nombre y/o los años de vigencia de una categoría."""
    nuevo = nuevo.strip().upper()
    if not nuevo:
        raise ValueError("Escriba el nombre de la categoría.")
    try:
        con.execute("UPDATE categorias SET codigo = ?, anios = ? WHERE codigo = ?",
                    (nuevo, int(anios), viejo))
        if nuevo != viejo:
            for tabla in TABLAS_LICENCIA:
                con.execute(f"UPDATE {tabla} SET categoria = ? WHERE categoria = ?", (nuevo, viejo))
                con.execute(f"UPDATE {tabla} SET categoria2 = ? WHERE categoria2 = ?", (nuevo, viejo))
        con.commit()
    except sqlite3.IntegrityError:
        con.rollback()
        raise ValueError(f"La categoría {nuevo} ya existe.")


def renombrar_categoria(con, viejo, nuevo):
    fila = con.execute("SELECT anios FROM categorias WHERE codigo = ?", (viejo,)).fetchone()
    editar_categoria(con, viejo, nuevo, fila["anios"] if fila else 10)


def eliminar_categoria(con, codigo):
    con.execute("DELETE FROM categorias WHERE codigo = ?", (codigo,))
    con.commit()
