"""Cifras para la pantalla de inicio (resumen y gráficos)."""
from datetime import date, timedelta

from .fechas import MESES_CORTOS


def _primer_dia(hoy, desplazar):
    m = hoy.month - 1 + desplazar
    return date(hoy.year + m // 12, m % 12 + 1, 1)


def _tramites_mes(con, hoy, desplazar):
    ini = _primer_dia(hoy, desplazar).isoformat()
    fin = _primer_dia(hoy, desplazar + 1).isoformat()
    r = con.execute("SELECT COUNT(*) AS c, COALESCE(SUM(valor), 0) AS v FROM tramites "
                    "WHERE fecha_entrega >= ? AND fecha_entrega < ?", (ini, fin)).fetchone()
    return r["c"], r["v"]


def variacion(actual, anterior):
    """Cambio porcentual contra el mes anterior (None si no hay base para comparar)."""
    if not anterior:
        return None
    return round((actual - anterior) * 100 / anterior)


def resumen(con, dias_aviso, hoy=None):
    hoy = hoy or date.today()
    limite = (hoy + timedelta(days=dias_aviso)).isoformat()
    h = hoy.isoformat()
    vencidos = por_vencer = total = 0
    for tabla in ("licencias", "expediciones", "seguros", "tecnomecanicas"):
        r = con.execute(
            f"SELECT COUNT(*) AS t, "
            f"COALESCE(SUM(fecha_vencimiento < ?), 0) AS v, "
            f"COALESCE(SUM(fecha_vencimiento >= ? AND fecha_vencimiento <= ?), 0) AS p "
            f"FROM {tabla}", (h, h, limite)).fetchone()
        total += r["t"]
        vencidos += r["v"]
        por_vencer += r["p"]
    al_dia = total - vencidos - por_vencer
    c_act, v_act = _tramites_mes(con, hoy, 0)
    c_ant, v_ant = _tramites_mes(con, hoy, -1)
    return {
        "vencidos": vencidos, "por_vencer": por_vencer, "documentos": total,
        "porcentaje_al_dia": round(al_dia * 100 / total) if total else None,
        "tramites_mes": c_act, "tramites_var": variacion(c_act, c_ant),
        "ingresos_mes": v_act, "ingresos_var": variacion(v_act, v_ant),
        "registros": sum(con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                         for t in ("licencias", "expediciones", "tramites", "seguros", "tecnomecanicas")),
    }


def tramites_por_mes(con, meses=6, hoy=None):
    """[(etiqueta, cantidad, valor)] de los últimos 'meses' meses, el actual al final."""
    hoy = hoy or date.today()
    datos = []
    for i in range(meses - 1, -1, -1):
        c, v = _tramites_mes(con, hoy, -i)
        datos.append((MESES_CORTOS[_primer_dia(hoy, -i).month - 1], c, v))
    return datos
