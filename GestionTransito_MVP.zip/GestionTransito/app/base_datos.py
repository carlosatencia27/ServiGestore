"""Base de datos SQLite (un solo archivo: datos/transito.db)."""
import os
import sqlite3
import unicodedata

from . import config

_LICENCIA = """(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    cedula TEXT NOT NULL,
    telefono TEXT,
    telefono2 TEXT,
    tipo TEXT NOT NULL DEFAULT '',
    categoria TEXT NOT NULL,
    categoria2 TEXT,
    fecha_realizada TEXT NOT NULL,
    fecha_vencimiento TEXT NOT NULL
)"""

ESQUEMA = f"""
CREATE TABLE IF NOT EXISTS categorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT NOT NULL UNIQUE,
    anios INTEGER NOT NULL DEFAULT 10
);
CREATE TABLE IF NOT EXISTS ajustes (
    clave TEXT PRIMARY KEY,
    valor TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS licencias {_LICENCIA};
CREATE TABLE IF NOT EXISTS expediciones {_LICENCIA};
CREATE TABLE IF NOT EXISTS tramites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    cedula TEXT NOT NULL,
    telefono TEXT,
    telefono2 TEXT,
    placa TEXT NOT NULL,
    transito INTEGER NOT NULL DEFAULT 0,
    traspaso INTEGER NOT NULL DEFAULT 0,
    traslado INTEGER NOT NULL DEFAULT 0,
    duplicado INTEGER NOT NULL DEFAULT 0,
    duplicado_tarjeta INTEGER NOT NULL DEFAULT 0,
    nit_tarjeta_lote TEXT,
    fecha_entrega TEXT,
    valor INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS seguros (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    cedula TEXT NOT NULL,
    telefono TEXT,
    telefono2 TEXT,
    placa TEXT NOT NULL,
    tecnomecanica INTEGER NOT NULL DEFAULT 0,
    fecha_inicio TEXT NOT NULL,
    fecha_vencimiento TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tecnomecanicas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    cedula TEXT NOT NULL,
    telefono TEXT,
    telefono2 TEXT,
    placa TEXT NOT NULL,
    fecha_inicio TEXT NOT NULL,
    fecha_vencimiento TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_lic_venc ON licencias(fecha_vencimiento);
CREATE INDEX IF NOT EXISTS idx_exp_venc ON expediciones(fecha_vencimiento);
CREATE INDEX IF NOT EXISTS idx_seg_venc ON seguros(fecha_vencimiento);
CREATE INDEX IF NOT EXISTS idx_tec_venc ON tecnomecanicas(fecha_vencimiento);
"""

# Columnas nuevas que se agregan a bases de datos creadas con versiones anteriores.
COLUMNAS_NUEVAS = [
    ("licencias", "telefono2", "TEXT"), ("licencias", "categoria2", "TEXT"),
    ("tramites", "telefono2", "TEXT"), ("seguros", "telefono2", "TEXT"),
    ("categorias", "anios", "INTEGER NOT NULL DEFAULT 10"),
]


def normalizar(texto):
    """Minúsculas y sin tildes, para que 'Muñoz' y 'munoz' coincidan al buscar."""
    if texto is None:
        return ""
    t = unicodedata.normalize("NFD", str(texto))
    return "".join(c for c in t if unicodedata.category(c) != "Mn").lower()


def _migrar(con):
    for tabla, columna, definicion in COLUMNAS_NUEVAS:
        existentes = {f["name"] for f in con.execute(f"PRAGMA table_info({tabla})")}
        if columna not in existentes:
            con.execute(f"ALTER TABLE {tabla} ADD COLUMN {columna} {definicion}")
    # Una sola vez: vigencias por categoría y lista de categorías actual (sin A1, B2 ni B3).
    hecho = con.execute("SELECT 1 FROM ajustes WHERE clave = 'categorias_v2'").fetchone()
    if not hecho:
        con.execute("UPDATE categorias SET anios = 3 WHERE codigo IN ('C1', 'C2', 'C3')")
        con.execute("DELETE FROM categorias WHERE codigo IN ('A1', 'B2', 'B3')")
        con.execute("INSERT INTO ajustes (clave, valor) VALUES ('categorias_v2', '1')")


def conectar(ruta=None):
    ruta = ruta or config.RUTA_DB
    if ruta != ":memory:":
        os.makedirs(os.path.dirname(ruta), exist_ok=True)
    con = sqlite3.connect(ruta)
    con.row_factory = sqlite3.Row
    con.create_function("norm", 1, normalizar)
    con.executescript(ESQUEMA)
    _migrar_previa = con.execute("SELECT COUNT(*) FROM categorias").fetchone()[0]
    if _migrar_previa == 0 and not con.execute(
            "SELECT 1 FROM ajustes WHERE clave = 'categorias_v2'").fetchone():
        con.executemany("INSERT INTO categorias (codigo, anios) VALUES (?, ?)",
                        config.CATEGORIAS_INICIALES)
    _migrar(con)
    con.executemany("INSERT OR IGNORE INTO ajustes (clave, valor) VALUES (?, ?)", [
        ("dias_aviso", str(config.DIAS_AVISO_DEFECTO)),
        ("vigencia_seguro_meses", str(config.VIGENCIA_SEGURO_MESES_DEFECTO)),
        ("vigencia_tecno_meses", str(config.VIGENCIA_TECNO_MESES_DEFECTO)),
    ])
    con.commit()
    return con
