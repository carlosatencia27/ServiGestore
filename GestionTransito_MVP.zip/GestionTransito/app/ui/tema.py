"""Paleta (claro, oscuro) y fuentes. El tema oscuro usa acento dorado; el claro, azul."""
import customtkinter as ctk

from .. import config

PALETA = {
    #                 claro        oscuro
    "fondo":        ("#F2F4F9", "#131416"),
    "sidebar":      ("#FFFFFF", "#1A1B1E"),
    "tarjeta":      ("#FFFFFF", "#1F2024"),
    "tarjeta2":     ("#F5F7FB", "#26272C"),
    "borde":        ("#E3E7EF", "#2F3036"),
    "texto":        ("#141A29", "#F1F2F4"),
    "suave":        ("#6A7388", "#9B9EA8"),
    "acento":       ("#2F63F2", "#F2B705"),
    "acento_hover": ("#2149C7", "#D9A304"),
    "acento_suave": ("#E4ECFF", "#3A3320"),
    "sobre_acento": ("#FFFFFF", "#16130A"),
    "hover":        ("#EDF1F9", "#2B2C32"),
    "ok":           ("#15803D", "#5BD68A"),
    "ok_bg":        ("#E1F5E8", "#1E3829"),
    "aviso":        ("#A15C07", "#F2B705"),
    "aviso_bg":     ("#FDF0D2", "#3A3320"),
    "peligro":      ("#C0332A", "#FF7A6E"),
    "peligro_bg":   ("#FCE6E4", "#40231F"),
    "neutro":       ("#4B5468", "#B6B9C2"),
    "neutro_bg":    ("#EAEDF4", "#303137"),
    "invertido":    ("#141A29", "#F1F2F4"),
    "sobre_invertido": ("#FFFFFF", "#141A29"),
}


def c(nombre):
    """Color como (claro, oscuro) para widgets de CustomTkinter."""
    return PALETA[nombre]


def actual(nombre):
    """Color único según el tema vigente (para dibujar en Canvas)."""
    return PALETA[nombre][1 if ctk.get_appearance_mode() == "Dark" else 0]


_fuentes = {}


def fuente(tam=None, negrita=False):
    tam = tam or config.TAMANO
    clave = (tam, negrita)
    if clave not in _fuentes:
        _fuentes[clave] = ctk.CTkFont(family=config.FUENTE, size=tam,
                                      weight="bold" if negrita else "normal")
    return _fuentes[clave]
