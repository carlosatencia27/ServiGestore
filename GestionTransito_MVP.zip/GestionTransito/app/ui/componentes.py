"""Componentes visuales reutilizables: tarjetas, botones, pastillas, avatar, avisos y diálogos."""
import tkinter as tk

import customtkinter as ctk

from . import tema
from .tema import c, fuente


class Tarjeta(ctk.CTkFrame):
    def __init__(self, padre, **kw):
        kw.setdefault("fg_color", c("tarjeta"))
        kw.setdefault("corner_radius", 16)
        kw.setdefault("border_width", 1)
        kw.setdefault("border_color", c("borde"))
        super().__init__(padre, **kw)


def boton(padre, texto, comando=None, tipo="secundario", ancho=None, alto=40, tam=None):
    """tipo: primario | secundario | fantasma | peligro"""
    estilos = {
        "primario":   dict(fg_color=c("acento"), hover_color=c("acento_hover"),
                           text_color=c("sobre_acento"), border_width=0),
        "secundario": dict(fg_color="transparent", hover_color=c("hover"),
                           text_color=c("texto"), border_width=1, border_color=c("borde")),
        "fantasma":   dict(fg_color="transparent", hover_color=c("hover"),
                           text_color=c("suave"), border_width=0),
        "peligro":    dict(fg_color="transparent", hover_color=c("peligro_bg"),
                           text_color=c("peligro"), border_width=0),
    }[tipo]
    kw = dict(text=texto, command=comando, height=alto, corner_radius=10,
              font=fuente(tam, tipo == "primario"), **estilos)
    if ancho:
        kw["width"] = ancho
    return ctk.CTkButton(padre, **kw)


def pastilla(padre, texto, tono="neutro", **kw):
    """Etiqueta redondeada de estado. tono: ok | aviso | peligro | neutro"""
    return ctk.CTkLabel(padre, text=f"  {texto}  ", height=28, corner_radius=14,
                        fg_color=c(tono + "_bg"), text_color=c(tono),
                        font=fuente(13, True), **kw)


def iniciales(nombre):
    partes = [p for p in nombre.split() if p]
    if not partes:
        return "?"
    return (partes[0][0] + (partes[1][0] if len(partes) > 1 else "")).upper()


def avatar(padre, nombre="", tam=40):
    return ctk.CTkLabel(padre, text=iniciales(nombre), width=tam, height=tam,
                        corner_radius=tam // 2, fg_color=c("acento_suave"),
                        text_color=c("acento"), font=fuente(15, True))


def corto(texto, maximo):
    texto = "" if texto is None else str(texto)
    return texto if len(texto) <= maximo else texto[:maximo - 1].rstrip() + "…"


class Aviso(ctk.CTkLabel):
    """Mensaje flotante breve (ej. «Registro guardado»)."""

    def __init__(self, padre):
        super().__init__(padre, text="", height=44, corner_radius=12,
                         fg_color=c("invertido"), text_color=c("sobre_invertido"),
                         font=fuente(15, True))
        self._after = None

    def mostrar(self, texto, ms=3200):
        self.configure(text=f"   ✓   {texto}   ")
        self.place(relx=1.0, rely=1.0, x=-28, y=-26, anchor="se")
        self.lift()
        if self._after:
            self.after_cancel(self._after)
        self._after = self.after(ms, self.place_forget)


class VentanaModal(ctk.CTkToplevel):
    """Ventana emergente con encabezado, cuerpo y pie. Se centra sobre la ventana principal."""

    def __init__(self, padre, titulo, subtitulo="", ancho=None):
        super().__init__(padre)
        self._padre = padre
        self.title(titulo)
        self.configure(fg_color=c("tarjeta"))
        self.transient(padre)
        self.resizable(False, False)
        self.withdraw()
        enc = ctk.CTkFrame(self, fg_color="transparent")
        enc.pack(fill="x", padx=30, pady=(26, 6))
        ctk.CTkLabel(enc, text=titulo, font=fuente(24, True), text_color=c("texto"),
                     anchor="w").pack(anchor="w")
        if subtitulo:
            ctk.CTkLabel(enc, text=subtitulo, font=fuente(15), text_color=c("suave"),
                         anchor="w").pack(anchor="w", pady=(2, 0))
        self.cuerpo = ctk.CTkFrame(self, fg_color="transparent")
        self.cuerpo.pack(fill="both", padx=30, pady=(14, 6))
        self.pie = ctk.CTkFrame(self, fg_color="transparent")
        self.pie.pack(fill="x", padx=30, pady=(8, 24))
        self._ancho = ancho
        self.bind("<Escape>", lambda ev: self.destroy())

    def abrir(self):
        self.update_idletasks()
        w = max(self._ancho or 0, self.winfo_reqwidth())
        h = self.winfo_reqheight()
        p = self._padre
        x = p.winfo_rootx() + max(0, (p.winfo_width() - w) // 2)
        y = p.winfo_rooty() + max(0, (p.winfo_height() - h) // 3)
        x = max(0, min(x, self.winfo_screenwidth() - w))
        y = max(0, min(y, self.winfo_screenheight() - h - 70))
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.deiconify()
        self.wait_visibility()
        self.lift()
        self.focus_force()
        self.grab_set()


def confirmar(padre, titulo, mensaje, texto_si="Eliminar", peligro=True):
    v = VentanaModal(padre, titulo, ancho=460)
    resultado = {"si": False}
    ctk.CTkLabel(v.cuerpo, text=mensaje, font=fuente(16), text_color=c("texto"),
                 justify="left", wraplength=400, anchor="w").pack(anchor="w")

    def si():
        resultado["si"] = True
        v.destroy()
    b = boton(v.pie, texto_si, si, "primario", 130)
    if peligro:
        b.configure(fg_color=c("peligro"), hover_color=c("peligro"), text_color="#FFFFFF")
    b.pack(side="right")
    boton(v.pie, "Cancelar", v.destroy, "secundario", 120).pack(side="right", padx=(0, 10))
    v.bind("<Return>", lambda ev: si())
    v.abrir()
    padre.wait_window(v)
    return resultado["si"]


def informar(padre, titulo, mensaje):
    v = VentanaModal(padre, titulo, ancho=460)
    ctk.CTkLabel(v.cuerpo, text=mensaje, font=fuente(16), text_color=c("texto"),
                 justify="left", wraplength=400, anchor="w").pack(anchor="w")
    boton(v.pie, "Entendido", v.destroy, "primario", 130).pack(side="right")
    v.bind("<Return>", lambda ev: v.destroy())
    v.abrir()
    padre.wait_window(v)


def pedir_texto(padre, titulo, etiqueta, inicial=""):
    v = VentanaModal(padre, titulo, ancho=460)
    ctk.CTkLabel(v.cuerpo, text=etiqueta, font=fuente(15, True), text_color=c("suave"),
                 anchor="w").pack(anchor="w", pady=(0, 6))
    entrada = ctk.CTkEntry(v.cuerpo, height=42, corner_radius=10, font=fuente(16),
                           fg_color=c("tarjeta2"), border_color=c("borde"), text_color=c("texto"))
    entrada.pack(fill="x")
    entrada.insert(0, inicial)
    resultado = {"valor": None}

    def aceptar():
        resultado["valor"] = entrada.get()
        v.destroy()
    boton(v.pie, "Aceptar", aceptar, "primario", 120).pack(side="right")
    boton(v.pie, "Cancelar", v.destroy, "secundario", 120).pack(side="right", padx=(0, 10))
    v.bind("<Return>", lambda ev: aceptar())
    v.abrir()
    entrada.focus_set()
    padre.wait_window(v)
    return resultado["valor"]
