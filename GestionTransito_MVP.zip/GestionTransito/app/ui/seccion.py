"""Sección genérica: encabezado, búsqueda, filtros, tabla y acciones."""
import csv
import sqlite3
from datetime import date
from tkinter import filedialog

import customtkinter as ctk

from .componentes import boton, confirmar, informar
from .formulario import Formulario
from .tabla import Tabla
from .tema import c, fuente


class Seccion(ctk.CTkFrame):
    """spec: titulo, descripcion, singular, boton_nuevo, archivo, repo, columnas, celdas,
    exportar, campos, filtros y opcionales: total_valor, extras [(texto, comando)]."""

    def __init__(self, padre, app, spec):
        super().__init__(padre, fg_color="transparent")
        self.app, self.spec, self.repo = app, spec, spec["repo"]
        self.filtro, self._pend, self._filas_db = 0, None, []

        cab = ctk.CTkFrame(self, fg_color="transparent")
        cab.pack(fill="x")
        izq = ctk.CTkFrame(cab, fg_color="transparent")
        izq.pack(side="left")
        ctk.CTkLabel(izq, text=spec["titulo"], font=fuente(30, True), text_color=c("texto"),
                     anchor="w").pack(anchor="w")
        ctk.CTkLabel(izq, text=spec["descripcion"], font=fuente(15), text_color=c("suave"),
                     anchor="w").pack(anchor="w")
        boton(cab, "+   " + spec["boton_nuevo"], self.agregar, "primario", 220, 46).pack(
            side="right", anchor="s")
        boton(cab, "Exportar", self.exportar, "secundario", 110, 40, 15).pack(
            side="right", anchor="s", padx=(0, 10))
        for texto, comando in reversed(spec.get("extras", [])):
            boton(cab, texto, comando, "secundario", None, 40, 15).pack(
                side="right", anchor="s", padx=(0, 10))

        barra = ctk.CTkFrame(self, fg_color="transparent")
        barra.pack(fill="x", pady=(18, 0))
        self.entrada = ctk.CTkEntry(barra, width=340, height=44, corner_radius=22, font=fuente(16),
                                    placeholder_text="Buscar por nombre, cédula o placa…",
                                    fg_color=c("tarjeta"), border_color=c("borde"),
                                    text_color=c("texto"), placeholder_text_color=c("suave"))
        self.entrada.pack(side="left")
        self.entrada.bind("<KeyRelease>", lambda ev: self._programar())
        self.chips = []
        for i, (etq, _) in enumerate(spec["filtros"]):
            b = ctk.CTkButton(barra, text=etq, height=38, corner_radius=19, font=fuente(15, True),
                              command=lambda i=i: self._elegir_filtro(i))
            b.pack(side="left", padx=(14 if i == 0 else 6, 0))
            self.chips.append(b)

        columnas = spec["columnas"] + [{
            "clave": "acciones", "titulo": "", "peso": 3.6, "tipo": "acciones",
            "acciones": [("Editar", "fantasma", self.editar), ("Eliminar", "peligro", self.eliminar)]}]
        self.tabla = Tabla(self, columnas)
        self.tabla.pack(fill="both", expand=True, pady=(16, 0))
        self._pintar_chips()
        self.recargar(reiniciar=True)

    # ---- filtros y búsqueda ----
    def _pintar_chips(self):
        for i, b in enumerate(self.chips):
            if i == self.filtro:
                b.configure(fg_color=c("acento_suave"), text_color=c("acento"),
                            hover_color=c("acento_suave"))
            else:
                b.configure(fg_color="transparent", text_color=c("suave"), hover_color=c("hover"))

    def _elegir_filtro(self, i):
        self.filtro = i
        self._pintar_chips()
        self.recargar(reiniciar=True)

    def _programar(self):
        if self._pend:
            self.after_cancel(self._pend)
        self._pend = self.after(180, lambda: self.recargar(reiniciar=True))

    def buscar_texto(self, texto):
        self.entrada.delete(0, "end")
        if texto:
            self.entrada.insert(0, texto)
        self.filtro = 0
        self._pintar_chips()
        self.recargar(reiniciar=True)

    def enfocar_busqueda(self):
        self.entrada.focus_set()

    # ---- datos ----
    def recargar(self, reiniciar=False):
        self._pend = None
        aviso, hoy = self.app.dias_aviso(), date.today()
        texto = self.entrada.get().strip()
        filas = self.repo.listar(texto)
        filtros = self.spec["filtros"]
        for i, b in enumerate(self.chips):
            n = sum(1 for f in filas if filtros[i][1](f, aviso, hoy))
            b.configure(text=f"{filtros[i][0]}  {n}")
        elegidas = [f for f in filas if filtros[self.filtro][1](f, aviso, hoy)]
        self._filas_db = elegidas
        datos = [{"id": f["id"], "celdas": self.spec["celdas"](f, aviso)} for f in elegidas]
        extra = ""
        if self.spec.get("total_valor"):
            extra = "Total: $ " + f"{sum(f['valor'] or 0 for f in elegidas):,}".replace(",", ".")
        if texto or self.filtro:
            self.tabla.vacio_texto = "Sin resultados\n\nRevise la búsqueda o cambie el filtro."
        else:
            self.tabla.vacio_texto = f"Aún no hay registros\n\nHaga clic en «+  {self.spec['boton_nuevo']}»\npara empezar."
        self.tabla.mostrar(datos, extra, volver_inicio=reiniciar)

    # ---- acciones ----
    def _guardado(self, mensaje):
        self.recargar()
        self.app.al_cambiar()
        self.app.avisar(mensaje)

    def agregar(self):
        datos = Formulario.pedir(self.winfo_toplevel(), f"Agregar {self.spec['singular']}",
                                 self.spec["campos"], validar=self.spec.get("validar"))
        if datos is None:
            return
        try:
            self.repo.insertar(datos)
        except (sqlite3.Error, KeyError, ValueError) as ex:
            return informar(self.winfo_toplevel(), "No se pudo guardar", str(ex))
        self.tabla.pagina = 0
        self._guardado("Registro guardado correctamente")

    def editar(self, id_):
        fila = self.repo.obtener(id_)
        if fila is None:
            return
        datos = Formulario.pedir(self.winfo_toplevel(), f"Editar {self.spec['singular']}",
                                 self.spec["campos"], dict(fila), validar=self.spec.get("validar"))
        if datos is None:
            return
        try:
            self.repo.actualizar(id_, datos)
        except (sqlite3.Error, KeyError, ValueError) as ex:
            return informar(self.winfo_toplevel(), "No se pudo guardar", str(ex))
        self._guardado("Cambios guardados")

    def eliminar(self, id_):
        fila = self.repo.obtener(id_)
        if fila is None:
            return
        if confirmar(self.winfo_toplevel(), "Eliminar registro",
                     f"¿Eliminar el registro de {fila['nombre']}?\n\nEsta acción no se puede deshacer."):
            self.repo.eliminar(id_)
            self._guardado("Registro eliminado")

    def exportar(self):
        nombre = f"{self.spec['archivo']}_{date.today():%Y%m%d}.csv"
        ruta = filedialog.asksaveasfilename(parent=self.winfo_toplevel(), title="Exportar a Excel",
                                            defaultextension=".csv", initialfile=nombre,
                                            filetypes=[("Archivo para Excel (CSV)", "*.csv")])
        if not ruta:
            return
        aviso = self.app.dias_aviso()
        try:
            with open(ruta, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f, delimiter=";")
                w.writerow([e for e, _ in self.spec["exportar"]])
                for fila in self._filas_db:
                    w.writerow([fn(fila, aviso) for _, fn in self.spec["exportar"]])
        except OSError as ex:
            return informar(self.winfo_toplevel(), "No se pudo exportar", str(ex))
        self.app.avisar("Archivo exportado. Ábralo con Excel")
