"""Ventana principal: menú lateral, barra superior y páginas."""
import base64
import io
import os
import sqlite3
import traceback
from datetime import date, datetime
from tkinter import filedialog

import customtkinter as ctk

from .. import config, fechas
from ..base_datos import conectar
from ..repositorio import guardar_ajuste, obtener_ajuste
from .ajustes import abrir_ajustes
from .componentes import Aviso, boton, informar
from .inicio import Inicio
from .seccion import Seccion
from .secciones import (spec_expediciones, spec_licencias, spec_seguro, spec_tecnomecanica,
                        spec_tramites)
from .tema import c, fuente

MENU = [("inicio", "⌂", "Vencimientos"),
        ("expediciones", "✚", "Expedición inicial"),
        ("licencias", "▤", "Refrendaciones"),
        ("tramites", "☰", "Trámites"),
        ("seguro", "◈", "Seguro"),
        ("tecnomecanica", "◎", "Tecnomecánica")]
SECCIONES = ("expediciones", "licencias", "tramites", "seguro", "tecnomecanica")


class ItemMenu:
    def __init__(self, padre, icono, texto, comando):
        self.comando = comando
        self.boton = ctk.CTkButton(padre, text=f" {icono}   {texto}", anchor="w", height=42,
                                   corner_radius=12, font=fuente(16), fg_color="transparent",
                                   hover_color=c("hover"), text_color=c("suave"), command=comando)
        self.badge = ctk.CTkLabel(self.boton, text="", width=28, height=24, corner_radius=12,
                                  fg_color=c("acento"), text_color=c("sobre_acento"),
                                  font=fuente(13, True))
        self.badge.bind("<Button-1>", lambda ev: comando())

    def pack(self, **kw):
        self.boton.pack(**kw)

    def seleccionar(self, si):
        self.boton.configure(fg_color=c("acento_suave") if si else "transparent",
                             hover_color=c("acento_suave") if si else c("hover"),
                             text_color=c("acento") if si else c("suave"),
                             font=fuente(16, si))

    def poner_contador(self, n):
        if n:
            self.badge.configure(text=str(n))
            self.badge.place(relx=1.0, x=-14, rely=0.5, anchor="e")
        else:
            self.badge.place_forget()


class App(ctk.CTk):
    def __init__(self, ruta_db=None):
        con = conectar(ruta_db)
        ctk.set_appearance_mode("dark" if obtener_ajuste(con, "tema", "dark") == "dark" else "light")
        super().__init__()
        self.con = con
        self.title(config.TITULO_APP)
        self.geometry("1320x780")
        self.minsize(1100, 680)
        self.configure(fg_color=c("fondo"))
        self.after(0, self._maximizar)
        self.report_callback_exception = self._error_inesperado

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # ---- menú lateral ----
        barra = ctk.CTkFrame(self, width=260, corner_radius=0, fg_color=c("sidebar"),
                             border_width=0)
        barra.grid(row=0, column=0, sticky="ns")
        barra.grid_propagate(False)
        barra.pack_propagate(False)
        marca = ctk.CTkFrame(barra, fg_color="transparent")
        marca.pack(fill="x", padx=22, pady=(20, 14))
        ctk.CTkLabel(marca, text="T", width=46, height=46, corner_radius=14, fg_color=c("acento"),
                     text_color=c("sobre_acento"), font=fuente(24, True)).pack(side="left")
        textos = ctk.CTkFrame(marca, fg_color="transparent")
        textos.pack(side="left", padx=12)
        ctk.CTkLabel(textos, text="Trámites", font=fuente(20, True), text_color=c("texto"),
                     anchor="w").pack(anchor="w")
        ctk.CTkLabel(textos, text="Gestión de tránsito", font=fuente(13), text_color=c("suave"),
                     anchor="w").pack(anchor="w")
        ctk.CTkLabel(barra, text="MENÚ", font=fuente(12, True), text_color=c("suave"),
                     anchor="w").pack(anchor="w", padx=28, pady=(0, 6))

        # ---- contenido ----
        derecha = ctk.CTkFrame(self, fg_color="transparent")
        derecha.grid(row=0, column=1, sticky="nsew")
        top = ctk.CTkFrame(derecha, fg_color="transparent", height=56)
        top.pack(fill="x", padx=30, pady=(14, 0))
        self.lbl_saludo = ctk.CTkLabel(top, text="", font=fuente(15), text_color=c("suave"), anchor="w")
        self.lbl_saludo.pack(side="left")
        self.b_tema = boton(top, "", self.alternar_tema, "secundario", 150, 38, 14)
        self.b_tema.pack(side="right")
        self.b_pend = ctk.CTkButton(top, text="", height=38, corner_radius=19, font=fuente(14, True),
                                    fg_color=c("acento_suave"), hover_color=c("acento_suave"),
                                    text_color=c("acento"), command=lambda: self.mostrar("inicio"))
        self.b_pend.pack(side="right", padx=(0, 10))

        self.contenido = ctk.CTkFrame(derecha, fg_color="transparent")
        self.contenido.pack(fill="both", expand=True, padx=30, pady=(4, 24))

        self.paginas = {
            "inicio": Inicio(self.contenido, self),
            "expediciones": Seccion(self.contenido, self, spec_expediciones(self)),
            "licencias": Seccion(self.contenido, self, spec_licencias(self)),
            "tramites": Seccion(self.contenido, self, spec_tramites(self)),
            "seguro": Seccion(self.contenido, self, spec_seguro(self)),
            "tecnomecanica": Seccion(self.contenido, self, spec_tecnomecanica(self)),
        }
        self.items = {}
        for clave, icono, texto in MENU:
            item = ItemMenu(barra, icono, texto, lambda k=clave: self.mostrar(k))
            item.pack(fill="x", padx=14, pady=1)
            self.items[clave] = item

        ctk.CTkLabel(barra, text="Created by: Carlos Atencia", font=fuente(11),
                     text_color=c("suave")).pack(side="bottom", pady=(0, 10))
        ctk.CTkLabel(barra, text="Ctrl+N  nuevo   ·   Ctrl+F  buscar", font=fuente(12),
                     text_color=c("suave")).pack(side="bottom", pady=(6, 18))
        for icono, texto, cmd in (("⇩", "Copia de seguridad", self.copia_seguridad),
                                  ("⚙", "Ajustes", lambda: abrir_ajustes(self))):
            ItemMenu(barra, icono, texto, cmd).pack(side="bottom", fill="x", padx=14, pady=1)

        self._poner_logo(barra)

        self.aviso = Aviso(self)
        for tecla in ("<Control-n>", "<Control-N>"):
            self.bind(tecla, lambda ev: self._atajo("agregar"))
        for tecla in ("<Control-f>", "<Control-F>"):
            self.bind(tecla, lambda ev: self._atajo("enfocar_busqueda"))
        self.bind("<F5>", lambda ev: self.al_cambiar(recargar_todo=True))

        self.actual = None
        self._texto_tema()
        self.mostrar("inicio")
        self._actualizar_barra()
        self.protocol("WM_DELETE_WINDOW", self._cerrar)

    def _poner_logo(self, barra):
        try:
            from PIL import Image
            from .logo_data import LOGO_PNG_BASE64, PROPORCION
            img = Image.open(io.BytesIO(base64.b64decode(LOGO_PNG_BASE64)))
            ancho = 212
            self._logo = ctk.CTkImage(light_image=img, dark_image=img,
                                      size=(ancho, round(ancho / PROPORCION)))
            marco = ctk.CTkFrame(barra, fg_color="#FFFFFF", corner_radius=14, border_width=1,
                                 border_color=c("borde"))
            marco.pack(side="bottom", fill="x", padx=14, pady=(6, 10))
            ctk.CTkLabel(marco, text="", image=self._logo).pack(padx=8, pady=9)
        except Exception:
            pass  # sin logo, el resto del programa funciona igual

    def _maximizar(self):
        try:
            self.state("zoomed")
        except Exception:
            pass

    # ---- navegación ----
    def dias_aviso(self):
        try:
            return int(obtener_ajuste(self.con, "dias_aviso", config.DIAS_AVISO_DEFECTO))
        except ValueError:
            return config.DIAS_AVISO_DEFECTO

    def mostrar(self, clave):
        if self.actual:
            self.paginas[self.actual].pack_forget()
        self.actual = clave
        self.paginas[clave].pack(fill="both", expand=True)
        self.paginas[clave].recargar()
        for k, item in self.items.items():
            item.seleccionar(k == clave)

    def ir_y_agregar(self, clave):
        self.mostrar(clave)
        self.paginas[clave].agregar()

    def abrir_registro(self, clave, cedula):
        self.mostrar(clave)
        self.paginas[clave].buscar_texto(cedula)

    def _atajo(self, metodo):
        pagina = self.paginas[self.actual]
        if hasattr(pagina, metodo):
            getattr(pagina, metodo)()

    def al_cambiar(self, recargar_todo=False):
        """Se llama después de guardar, editar o eliminar algo."""
        self.paginas["inicio"].recargar()
        if recargar_todo:
            for k in SECCIONES:
                self.paginas[k].recargar()
        self._actualizar_barra()

    def _actualizar_barra(self):
        n = self.paginas["inicio"].cantidad
        self.items["inicio"].poner_contador(n)
        if n:
            self.b_pend.configure(text=f"●  {n} por atender")
            self.b_pend.pack(side="right", padx=(0, 10))
        else:
            self.b_pend.pack_forget()
        h = datetime.now().hour
        hola = "Buenos días" if h < 12 else "Buenas tardes" if h < 19 else "Buenas noches"
        self.lbl_saludo.configure(text=f"{hola}   ·   {fechas.fecha_larga(date.today())}")

    # ---- tema ----
    def _texto_tema(self):
        oscuro = ctk.get_appearance_mode() == "Dark"
        self.b_tema.configure(text="☀   Modo claro" if oscuro else "☾   Modo oscuro")

    def aplicar_tema(self, modo):
        ctk.set_appearance_mode(modo)
        guardar_ajuste(self.con, "tema", modo)
        self._texto_tema()
        self.after(60, self.paginas["inicio"].redibujar)

    def alternar_tema(self):
        self.aplicar_tema("light" if ctk.get_appearance_mode() == "Dark" else "dark")

    # ---- utilidades ----
    def avisar(self, texto):
        self.aviso.mostrar(texto)

    def copia_seguridad(self):
        ruta = filedialog.asksaveasfilename(
            parent=self, title="Guardar copia de seguridad", defaultextension=".db",
            initialfile=f"copia_transito_{date.today():%Y%m%d}.db",
            filetypes=[("Base de datos", "*.db")])
        if not ruta:
            return
        try:
            destino = sqlite3.connect(ruta)
            self.con.backup(destino)
            destino.close()
        except (sqlite3.Error, OSError) as ex:
            return informar(self, "No se pudo copiar", str(ex))
        informar(self, "Copia lista", "Copia de seguridad guardada.\nGuárdela también en una memoria USB.")

    def _error_inesperado(self, tipo, valor, tb):
        try:
            os.makedirs(config.CARPETA_DATOS, exist_ok=True)
            with open(os.path.join(config.CARPETA_DATOS, "error.log"), "a", encoding="utf-8") as f:
                f.write("".join(traceback.format_exception(tipo, valor, tb)) + "\n")
        except OSError:
            pass
        try:
            informar(self, "Algo salió mal", "Ocurrió un problema inesperado.\nSe guardó el detalle en datos\\error.log")
        except Exception:
            pass

    def _cerrar(self):
        self.con.close()
        self.destroy()
