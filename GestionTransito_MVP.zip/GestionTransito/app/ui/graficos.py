"""Gráficos dibujados a mano (sin librerías pesadas): barras y dona."""
import tkinter as tk

from . import tema
from .tema import actual


def _rect_redondo(cv, x0, y0, x1, y1, r, **kw):
    r = max(0, min(r, (x1 - x0) / 2, (y1 - y0) / 2))
    pts = [x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r, x1, y1 - r, x1, y1,
           x1 - r, y1, x0 + r, y1, x0, y1, x0, y1 - r, x0, y0 + r, x0, y0]
    return cv.create_polygon(pts, smooth=True, **kw)


class Barras(tk.Canvas):
    """datos: [(etiqueta, valor)]. La última barra (mes actual) va con el color de acento."""

    def __init__(self, padre, fondo="tarjeta", **kw):
        super().__init__(padre, highlightthickness=0, bd=0, **kw)
        self.datos, self._fondo = [], fondo
        self.bind("<Configure>", lambda ev: self.dibujar())

    def poner(self, datos):
        self.datos = datos
        self.dibujar()

    def dibujar(self):
        self.delete("all")
        self.configure(bg=actual(self._fondo))
        w, h = self.winfo_width(), self.winfo_height()
        if not self.datos or w < 60 or h < 40:
            return
        maximo = max(v for _, v in self.datos) or 1
        n = len(self.datos)
        base, tope = h - 26, (26 if h >= 110 else 16)
        paso = w / n
        ancho = min(paso * 0.52, 44)
        for i, (etq, val) in enumerate(self.datos):
            x0 = paso * i + (paso - ancho) / 2
            alto = (base - tope) * val / maximo
            y0 = base - max(alto, 4)
            ultima = i == n - 1
            _rect_redondo(self, x0, y0, x0 + ancho, base, 7,
                          fill=actual("acento") if ultima else actual("acento_suave"), outline="")
            self.create_text(x0 + ancho / 2, y0 - 10, text=str(val), font=(tema.config.FUENTE, 11, "bold"),
                             fill=actual("texto") if ultima else actual("suave"))
            self.create_text(x0 + ancho / 2, h - 11, text=etq,
                             font=(tema.config.FUENTE, 11), fill=actual("suave"))


class Dona(tk.Canvas):
    """Anillo de progreso con porcentaje en el centro (None = sin datos)."""

    def __init__(self, padre, fondo="tarjeta", **kw):
        super().__init__(padre, highlightthickness=0, bd=0, **kw)
        self.valor, self.subtitulo, self._fondo = None, "", fondo
        self.bind("<Configure>", lambda ev: self.dibujar())

    def poner(self, valor, subtitulo=""):
        self.valor, self.subtitulo = valor, subtitulo
        self.dibujar()

    def dibujar(self):
        self.delete("all")
        self.configure(bg=actual(self._fondo))
        w, h = self.winfo_width(), self.winfo_height()
        if w < 60 or h < 60:
            return
        lado = min(w, h) - 16
        grosor = max(10, lado // 9)
        x0, y0 = (w - lado) / 2 + grosor / 2, (h - lado) / 2 + grosor / 2
        x1, y1 = x0 + lado - grosor, y0 + lado - grosor
        self.create_oval(x0, y0, x1, y1, outline=actual("borde"), width=grosor)
        if self.valor:
            self.create_arc(x0, y0, x1, y1, start=90, extent=-min(359.9, 360 * self.valor / 100),
                            style="arc", outline=actual("acento"), width=grosor)
        txt = "—" if self.valor is None else f"{self.valor}%"
        self.create_text(w / 2, h / 2 - 10, text=txt, fill=actual("texto"),
                         font=(tema.config.FUENTE, max(16, lado // 6), "bold"))
        if self.subtitulo:
            self.create_text(w / 2, h / 2 + max(14, lado // 9), text=self.subtitulo,
                             fill=actual("suave"), font=(tema.config.FUENTE, 10))
