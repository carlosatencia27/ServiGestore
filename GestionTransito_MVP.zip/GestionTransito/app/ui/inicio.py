"""Pantalla de inicio: resumen, gráficos y lista de lo que requiere atención."""
from datetime import date

import customtkinter as ctk

from .. import estadisticas, fechas, vencimientos
from .componentes import Tarjeta, boton
from .graficos import Barras, Dona
from .tabla import Tabla
from .tema import c, fuente


def _variacion(pct):
    if pct is None:
        return ("Sin datos del mes anterior", "suave")
    if pct == 0:
        return ("= Igual que el mes anterior", "suave")
    return (f"{'▲' if pct > 0 else '▼'} {abs(pct)}% vs mes anterior", "ok" if pct > 0 else "peligro")


class Inicio(ctk.CTkFrame):
    def __init__(self, padre, app):
        super().__init__(padre, fg_color="transparent")
        self.app = app
        self._destinos = []

        cab = ctk.CTkFrame(self, fg_color="transparent")
        cab.pack(fill="x")
        izq = ctk.CTkFrame(cab, fg_color="transparent")
        izq.pack(side="left")
        ctk.CTkLabel(izq, text="Próximos vencimientos", font=fuente(30, True),
                     text_color=c("texto"), anchor="w").pack(anchor="w")
        self.sub = ctk.CTkLabel(izq, text="", font=fuente(15), text_color=c("suave"), anchor="w")
        self.sub.pack(anchor="w")
        self._nuevos = {"Expedición inicial": "expediciones", "Refrendación": "licencias",
                        "Trámite": "tramites", "Seguro": "seguro", "Tecnomecánica": "tecnomecanica"}
        self.menu_nuevo = ctk.CTkOptionMenu(
            cab, values=list(self._nuevos), command=self._nuevo, width=210, height=46, corner_radius=10,
            font=fuente(16, True), dropdown_font=fuente(16), fg_color=c("acento"),
            button_color=c("acento_hover"), button_hover_color=c("acento_hover"),
            text_color=c("sobre_acento"), dropdown_fg_color=c("tarjeta"),
            dropdown_text_color=c("texto"), dropdown_hover_color=c("hover"))
        self.menu_nuevo.set("+   Nuevo registro")
        self.menu_nuevo.pack(side="right", anchor="s")

        kpis = ctk.CTkFrame(self, fg_color="transparent")
        kpis.pack(fill="x", pady=(18, 0))
        self.k_venc = self._kpi(kpis, 0, "Vencidos", "■")
        self.k_por = self._kpi(kpis, 1, "Por vencer", "▲")
        self.k_tram = self._kpi(kpis, 2, "Trámites del mes", "☰")
        self.k_ing = self._kpi(kpis, 3, "Ingresos del mes", "$")

        inf = ctk.CTkFrame(self, fg_color="transparent")
        inf.pack(fill="both", expand=True, pady=(18, 0))
        inf.grid_columnconfigure(0, weight=1)
        inf.grid_columnconfigure(1, weight=0, minsize=310)
        inf.grid_rowconfigure(0, weight=1)

        izq = ctk.CTkFrame(inf, fg_color="transparent")
        izq.grid(row=0, column=0, sticky="nsew", padx=(0, 18))
        ctk.CTkLabel(izq, text="Requieren atención", font=fuente(19, True), text_color=c("texto"),
                     anchor="w").pack(anchor="w", pady=(0, 8))
        columnas = [
            {"clave": "persona", "titulo": "CLIENTE", "peso": 6.0, "tipo": "persona", "maximo": 22},
            {"clave": "vence", "titulo": "VENCE", "peso": 2.4, "tipo": "texto"},
            {"clave": "estado", "titulo": "ESTADO", "peso": 4.6, "tipo": "pastilla"},
            {"clave": "abrir", "titulo": "", "peso": 1.0, "tipo": "acciones",
             "acciones": [("›", "fantasma", self._abrir)]}]
        self.tabla = Tabla(izq, columnas, vacio="✓  Todo al día\n\nNo hay licencias ni seguros\nvencidos o por vencer.")
        self.tabla.pack(fill="both", expand=True)

        der = ctk.CTkFrame(inf, fg_color="transparent")
        der.grid(row=0, column=1, sticky="nsew")
        der.grid_rowconfigure(1, weight=1)
        der.grid_columnconfigure(0, weight=1)
        t1 = Tarjeta(der)
        t1.grid(row=0, column=0, sticky="ew")
        ctk.CTkLabel(t1, text="Documentos al día", font=fuente(17, True), text_color=c("texto"),
                     anchor="w").pack(anchor="w", padx=20, pady=(16, 0))
        self.dona = Dona(t1, height=170)
        self.dona.pack(fill="x", padx=20, pady=(4, 10))
        t2 = Tarjeta(der)
        t2.grid(row=1, column=0, sticky="nsew", pady=(18, 0))
        ctk.CTkLabel(t2, text="Trámites por mes", font=fuente(17, True), text_color=c("texto"),
                     anchor="w").pack(anchor="w", padx=20, pady=(16, 0))
        self.barras = Barras(t2, height=150)
        self.barras.pack(fill="both", expand=True, padx=14, pady=(6, 12))
        self.recargar()

    def _kpi(self, padre, col, titulo, glifo):
        padre.grid_columnconfigure(col, weight=1, uniform="k")
        t = Tarjeta(padre)
        t.grid(row=0, column=col, sticky="nsew", padx=(0, 16) if col < 3 else 0)
        fila = ctk.CTkFrame(t, fg_color="transparent")
        fila.pack(fill="x", padx=20, pady=(16, 0))
        ctk.CTkLabel(fila, text=titulo, font=fuente(15), text_color=c("suave"), anchor="w").pack(side="left")
        ctk.CTkLabel(fila, text=glifo, width=34, height=34, corner_radius=10, fg_color=c("acento_suave"),
                     text_color=c("acento"), font=fuente(16, True)).pack(side="right")
        valor = ctk.CTkLabel(t, text="0", font=fuente(34, True), text_color=c("texto"), anchor="w")
        valor.pack(anchor="w", padx=20)
        nota = ctk.CTkLabel(t, text="", font=fuente(14), text_color=c("suave"), anchor="w")
        nota.pack(anchor="w", padx=20, pady=(0, 16))
        valor.nota = nota
        return valor

    def _nuevo(self, opcion):
        self.menu_nuevo.set("+   Nuevo registro")
        self.app.ir_y_agregar(self._nuevos[opcion])

    def _abrir(self, indice):
        clave, cedula = self._destinos[indice]
        self.app.abrir_registro(clave, cedula)

    def redibujar(self):
        self.dona.dibujar()
        self.barras.dibujar()

    def recargar(self):
        aviso = self.app.dias_aviso()
        con = self.app.con
        self.sub.configure(text=f"Ya vencidos o que vencen en los próximos {fechas.texto_dias(aviso)}.")
        r = estadisticas.resumen(con, aviso)
        self.k_venc.configure(text=str(r["vencidos"]))
        self.k_venc.nota.configure(text="Requieren renovación ya" if r["vencidos"] else "Ninguno, ¡bien!",
                                   text_color=c("peligro" if r["vencidos"] else "ok"))
        self.k_por.configure(text=str(r["por_vencer"]))
        self.k_por.nota.configure(text=f"En los próximos {fechas.texto_dias(aviso)}",
                                  text_color=c("aviso" if r["por_vencer"] else "suave"))
        txt, tono = _variacion(r["tramites_var"])
        self.k_tram.configure(text=str(r["tramites_mes"]))
        self.k_tram.nota.configure(text=txt, text_color=c(tono))
        txt, tono = _variacion(r["ingresos_var"])
        self.k_ing.configure(text="$ " + f"{r['ingresos_mes']:,}".replace(",", "."))
        self.k_ing.nota.configure(text=txt, text_color=c(tono))
        self.dona.poner(r["porcentaje_al_dia"], f"{r['documentos']} documentos" if r["documentos"] else "")
        self.barras.poner([(m, n) for m, n, _ in estadisticas.tramites_por_mes(con)])

        filas, self._destinos = [], []
        for n, f in enumerate(vencimientos.proximos(con, aviso)):
            self._destinos.append((f["clave"], f["cedula"]))
            texto, tono = vencimientos.estado_pastilla(f["vence"].isoformat(), aviso)
            filas.append({"id": n, "celdas": {
                "persona": (f["nombre"], f"{f['seccion']} · {f['detalle']}"),
                "vence": f["vence"].strftime("%d/%m/%Y"),
                "estado": (texto, tono)}})
        self.cantidad = len(filas)
        self.tabla.mostrar(filas, volver_inicio=False)
        return len(filas)
