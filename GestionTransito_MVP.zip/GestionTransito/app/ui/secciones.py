"""Definición de las secciones: columnas de la tabla, formulario y filtros."""
from .. import config, fechas, vencimientos
from ..repositorio import Repositorio, listar_categorias, obtener_ajuste
from .ajustes import DialogoCategorias

TIPOS_TRAMITE = [("transito", "Tránsito"), ("traspaso", "Traspaso"), ("traslado", "Traslado"),
                 ("duplicado", "Duplicado"), ("duplicado_tarjeta", "Duplicado de tarjeta")]


def _f(texto_iso):
    return fechas.formatear(texto_iso) or "—"


def _pesos(valor):
    return f"$ {valor:,}".replace(",", ".")


def _estado(fila, aviso):
    return vencimientos.estado_pastilla(fila["fecha_vencimiento"], aviso)


def _telefonos(fila):
    return (fila["telefono"] or "—", fila["telefono2"] or "")


def _filtros_estado():
    def hay(tono):
        return lambda f, aviso, hoy: vencimientos.estado_pastilla(f["fecha_vencimiento"], aviso, hoy)[1] == tono
    return [("Todos", lambda f, a, h: True), ("Vencidos", hay("peligro")),
            ("Por vencer", hay("aviso")), ("Vigentes", hay("ok"))]


def _campos_persona():
    return [
        {"clave": "nombre", "etiqueta": "Nombre", "tipo": "texto", "obligatorio": True},
        {"clave": "cedula", "etiqueta": "Cédula", "tipo": "texto", "obligatorio": True},
        {"clave": "telefono", "etiqueta": "Teléfono", "tipo": "texto"},
        {"clave": "telefono2", "etiqueta": "Teléfono 2 (opcional)", "tipo": "texto"},
    ]


def _documento_licencia(f):
    cats = vencimientos.texto_categorias(f)
    tipo = vencimientos.tipo_de_categoria(f["categoria"], f["tipo"])
    return f"{cats} · {tipo.capitalize()}" if tipo and not f["categoria2"] else cats


def _spec_licencia(app, tabla, titulo, descripcion, singular, boton_nuevo, archivo):
    """Expedición inicial y Refrendación llevan exactamente lo mismo."""
    def derivar(d, previo=None):
        tipo_previo = (previo or {}).get("tipo")
        d["fecha_vencimiento"] = vencimientos.vencimiento_por_categorias(
            app.con, [d["categoria"], d.get("categoria2")], fechas.de_iso(d["fecha_realizada"]),
            tipo_previo).isoformat()
        d["tipo"] = vencimientos.tipo_de_categoria(d["categoria"], tipo_previo)
        d["categoria2"] = d.get("categoria2") or ""
        return d

    def validar(d):
        if d["categoria2"] and d["categoria2"] == d["categoria"]:
            return "Elija dos categorías distintas."
        return None

    repo = Repositorio(app.con, tabla, [
        "nombre", "cedula", "telefono", "telefono2", "tipo", "categoria", "categoria2",
        "fecha_realizada", "fecha_vencimiento"], derivar)
    return {
        "titulo": titulo, "descripcion": descripcion, "singular": singular,
        "boton_nuevo": boton_nuevo, "archivo": archivo, "repo": repo, "vence": True,
        "filtros": _filtros_estado(), "validar": validar,
        "columnas": [
            {"clave": "persona", "titulo": "CLIENTE", "peso": 4.0, "tipo": "persona", "maximo": 22},
            {"clave": "telefono", "titulo": "TELÉFONO", "peso": 2.4, "tipo": "doble", "maximo": 14},
            {"clave": "documento", "titulo": "LICENCIA", "peso": 2.7, "tipo": "texto", "maximo": 18},
            {"clave": "realizada", "titulo": "REALIZADA", "peso": 2.0, "tipo": "texto"},
            {"clave": "vence", "titulo": "VENCE", "peso": 2.0, "tipo": "texto"},
            {"clave": "estado", "titulo": "ESTADO", "peso": 4.0, "tipo": "pastilla"}],
        "celdas": lambda f, aviso: {
            "persona": (f["nombre"], f"CC {f['cedula']}"), "telefono": _telefonos(f),
            "documento": _documento_licencia(f),
            "realizada": _f(f["fecha_realizada"]), "vence": _f(f["fecha_vencimiento"]),
            "estado": _estado(f, aviso)},
        "exportar": [
            ("Nombre", lambda f, a: f["nombre"]), ("Cédula", lambda f, a: f["cedula"]),
            ("Teléfono", lambda f, a: f["telefono"] or ""), ("Teléfono 2", lambda f, a: f["telefono2"] or ""),
            ("Categoría", lambda f, a: f["categoria"]), ("Categoría 2", lambda f, a: f["categoria2"] or ""),
            ("Fecha realizada", lambda f, a: _f(f["fecha_realizada"])),
            ("Vence", lambda f, a: _f(f["fecha_vencimiento"])),
            ("Estado", lambda f, a: _estado(f, a)[0])],
        "campos": _campos_persona() + [
            {"clave": "categoria", "etiqueta": "Categoría", "tipo": "combo", "obligatorio": True,
             "opciones": lambda: listar_categorias(app.con), "vacio": "Seleccione…"},
            {"clave": "categoria2", "etiqueta": "Segunda categoría (opcional)", "tipo": "combo",
             "opciones": lambda: listar_categorias(app.con), "vacio": "Ninguna", "incluir_vacio": True},
            {"clave": "fecha_realizada", "etiqueta": "Fecha en que se realizó", "tipo": "fecha",
             "obligatorio": True, "hoy": True},
        ],
        "extras": [("Categorías", lambda: DialogoCategorias(app, app.con))],
    }


def spec_expediciones(app):
    return _spec_licencia(
        app, "expediciones", "Expedición inicial de licencias",
        "Licencias nuevas. El vencimiento se calcula solo según la categoría.",
        "expedición", "Nueva expedición", "expediciones")


def spec_licencias(app):
    return _spec_licencia(
        app, "licencias", "Refrendaciones de licencias",
        "Refrendaciones. El vencimiento se calcula solo según la categoría.",
        "refrendación", "Nueva refrendación", "refrendaciones")


def spec_tramites(app):
    cols_db = ["nombre", "cedula", "telefono", "telefono2", "placa"] + [k for k, _ in TIPOS_TRAMITE] + [
        "nit_tarjeta_lote", "fecha_entrega", "valor"]
    repo = Repositorio(app.con, "tramites", cols_db)

    def tipos(f):
        return ", ".join(e for k, e in TIPOS_TRAMITE if f[k]) or "—"

    def este_mes(f, aviso, hoy):
        d = fechas.de_iso(f["fecha_entrega"])
        return bool(d) and (d.year, d.month) == (hoy.year, hoy.month)

    return {
        "titulo": "Trámites", "descripcion": "Trámites realizados, su entrega y su valor.",
        "singular": "trámite", "boton_nuevo": "Nuevo trámite", "archivo": "tramites",
        "repo": repo, "total_valor": True,
        "filtros": [("Todos", lambda f, a, h: True), ("Este mes", este_mes)],
        "columnas": [
            {"clave": "persona", "titulo": "CLIENTE", "peso": 4.2, "tipo": "persona", "maximo": 22},
            {"clave": "telefono", "titulo": "TELÉFONO", "peso": 2.4, "tipo": "doble", "maximo": 14},
            {"clave": "placa", "titulo": "PLACA", "peso": 1.8, "tipo": "negrita"},
            {"clave": "tramite", "titulo": "TRÁMITE", "peso": 3.6, "tipo": "texto", "maximo": 26},
            {"clave": "nit", "titulo": "NIT / LOTE", "peso": 2.0, "tipo": "texto", "maximo": 12},
            {"clave": "entrega", "titulo": "ENTREGA", "peso": 2.0, "tipo": "texto"},
            {"clave": "valor", "titulo": "VALOR", "peso": 2.2, "tipo": "negrita"}],
        "celdas": lambda f, aviso: {
            "persona": (f["nombre"], f"CC {f['cedula']}"), "telefono": _telefonos(f),
            "placa": f["placa"], "tramite": tipos(f),
            "nit": f["nit_tarjeta_lote"] or "—", "entrega": _f(f["fecha_entrega"]),
            "valor": _pesos(f["valor"] or 0)},
        "exportar": [
            ("Nombre", lambda f, a: f["nombre"]), ("Cédula", lambda f, a: f["cedula"]),
            ("Teléfono", lambda f, a: f["telefono"] or ""), ("Teléfono 2", lambda f, a: f["telefono2"] or ""),
            ("Placa", lambda f, a: f["placa"]), ("Trámite", lambda f, a: tipos(f)),
            ("NIT tarjeta / lote", lambda f, a: f["nit_tarjeta_lote"] or ""),
            ("Fecha entrega", lambda f, a: _f(f["fecha_entrega"])),
            ("Valor", lambda f, a: f["valor"] or 0)],
        "campos": _campos_persona() + [
            {"clave": "placa", "etiqueta": "Placa", "tipo": "texto", "obligatorio": True,
             "mayusculas": True},
            {"clave": "nit_tarjeta_lote", "etiqueta": "NIT de la tarjeta o lote", "tipo": "texto"},
            {"tipo": "checks", "etiqueta": "Tipo de trámite (marque uno o varios)",
             "opciones": TIPOS_TRAMITE},
            {"clave": "fecha_entrega", "etiqueta": "Fecha de entrega", "tipo": "fecha"},
            {"clave": "valor", "etiqueta": "Valor ($)", "tipo": "dinero"},
        ],
    }


def _spec_vehiculo(app, tabla, ajuste, titulo, descripcion, singular, boton_nuevo, archivo, extras_db=(),
                   extra_columnas=(), extra_celdas=None, extra_exportar=(), extra_campos=()):
    """Seguro y Tecnomecánica: placa + fecha de inicio, vence a los N meses."""
    def derivar(d, previo=None):
        meses = int(obtener_ajuste(app.con, ajuste, 12))
        d["fecha_vencimiento"] = vencimientos.vencimiento_seguro(
            fechas.de_iso(d["fecha_inicio"]), meses).isoformat()
        return d

    repo = Repositorio(app.con, tabla, [
        "nombre", "cedula", "telefono", "telefono2", "placa", *extras_db,
        "fecha_inicio", "fecha_vencimiento"], derivar)
    return {
        "titulo": titulo, "descripcion": descripcion, "singular": singular,
        "boton_nuevo": boton_nuevo, "archivo": archivo, "repo": repo, "vence": True,
        "filtros": _filtros_estado(),
        "columnas": [
            {"clave": "persona", "titulo": "CLIENTE", "peso": 4.2, "tipo": "persona", "maximo": 22},
            {"clave": "telefono", "titulo": "TELÉFONO", "peso": 2.4, "tipo": "doble", "maximo": 14},
            {"clave": "placa", "titulo": "PLACA", "peso": 1.8, "tipo": "negrita"},
            *extra_columnas,
            {"clave": "inicio", "titulo": "INICIO", "peso": 2.0, "tipo": "texto"},
            {"clave": "vence", "titulo": "VENCE", "peso": 2.0, "tipo": "texto"},
            {"clave": "estado", "titulo": "ESTADO", "peso": 4.0, "tipo": "pastilla"}],
        "celdas": lambda f, aviso: {
            "persona": (f["nombre"], f"CC {f['cedula']}"), "telefono": _telefonos(f),
            "placa": f["placa"], **(extra_celdas(f) if extra_celdas else {}),
            "inicio": _f(f["fecha_inicio"]), "vence": _f(f["fecha_vencimiento"]),
            "estado": _estado(f, aviso)},
        "exportar": [
            ("Nombre", lambda f, a: f["nombre"]), ("Cédula", lambda f, a: f["cedula"]),
            ("Teléfono", lambda f, a: f["telefono"] or ""), ("Teléfono 2", lambda f, a: f["telefono2"] or ""),
            ("Placa", lambda f, a: f["placa"]), *extra_exportar,
            ("Fecha inicio", lambda f, a: _f(f["fecha_inicio"])),
            ("Vence", lambda f, a: _f(f["fecha_vencimiento"])),
            ("Estado", lambda f, a: _estado(f, a)[0])],
        "campos": _campos_persona() + [
            {"clave": "placa", "etiqueta": "Placa", "tipo": "texto", "obligatorio": True,
             "mayusculas": True},
            {"clave": "fecha_inicio", "etiqueta": "Fecha de inicio", "tipo": "fecha",
             "obligatorio": True, "hoy": True},
            *extra_campos],
    }


def spec_seguro(app):
    return _spec_vehiculo(
        app, "seguros", "vigencia_seguro_meses", "Seguro",
        "Seguros de los clientes y cuándo vencen.", "seguro", "Nuevo seguro", "seguros",
        extras_db=("tecnomecanica",),
        extra_columnas=[{"clave": "tecno", "titulo": "TECNOMECÁNICA", "peso": 3.0, "tipo": "pastilla"}],
        extra_celdas=lambda f: {"tecno": ("Incluida", "ok") if f["tecnomecanica"] else ("No incluida", "neutro")},
        extra_exportar=[("Tecnomecánica", lambda f, a: "Sí" if f["tecnomecanica"] else "No")],
        extra_campos=[{"clave": "tecnomecanica", "etiqueta": "Tecnomecánica", "tipo": "check",
                       "texto": "Incluye tecnomecánica"}])


def spec_tecnomecanica(app):
    return _spec_vehiculo(
        app, "tecnomecanicas", "vigencia_tecno_meses", "Tecnomecánica",
        "Revisión técnico-mecánica de los vehículos y cuándo vence.",
        "tecnomecánica", "Nueva tecnomecánica", "tecnomecanicas")
