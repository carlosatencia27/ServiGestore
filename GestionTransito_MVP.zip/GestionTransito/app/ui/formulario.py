"""Formulario genérico (agregar / editar) con el estilo nuevo."""
import tkinter as tk
from datetime import date

import customtkinter as ctk

from .. import fechas
from .componentes import VentanaModal, boton
from .tema import c, fuente


def _entrada(padre, **kw):
    return ctk.CTkEntry(padre, height=44, corner_radius=10, font=fuente(16),
                        fg_color=c("tarjeta2"), border_color=c("borde"),
                        text_color=c("texto"), **kw)


class Formulario(VentanaModal):
    """campos: dicts con 'clave', 'etiqueta', 'tipo' y opcionales
    'obligatorio', 'opciones', 'mayusculas', 'hoy', 'ancho', 'min', 'max', 'texto'.
    Tipos: texto, fecha, combo, check, checks, dinero, entero."""

    def __init__(self, padre, titulo, campos, valores=None, subtitulo="Los campos con * son obligatorios.",
                 validar=None):
        super().__init__(padre, titulo, subtitulo, ancho=700)
        self._validar = validar
        self.resultado = None
        self._campos = campos
        self._vars, self._widgets = {}, {}
        valores = valores or {}

        self.cuerpo.grid_columnconfigure(0, weight=1, uniform="f")
        self.cuerpo.grid_columnconfigure(1, weight=1, uniform="f")
        fila = col = 0
        for campo in campos:
            ancho = campo.get("ancho") or campo["tipo"] in ("checks", "check")
            if ancho and col == 1:
                fila, col = fila + 1, 0
            celda = self._celda(campo, valores)
            if ancho:
                celda.grid(row=fila, column=0, columnspan=2, sticky="ew", pady=(0, 14))
                fila, col = fila + 1, 0
            else:
                celda.grid(row=fila, column=col, sticky="ew", pady=(0, 14),
                           padx=(0, 16) if col == 0 else 0)
                col += 1
                if col == 2:
                    fila, col = fila + 1, 0

        self.lbl_error = ctk.CTkLabel(self.pie, text="", font=fuente(15, True),
                                      text_color=c("peligro"), anchor="w")
        self.lbl_error.pack(side="left")
        boton(self.pie, "Guardar", self._guardar, "primario", 140, 44).pack(side="right")
        boton(self.pie, "Cancelar", self.destroy, "secundario", 120, 44).pack(side="right", padx=(0, 10))
        self.bind("<Return>", lambda ev: self._guardar())
        self.abrir()
        primero = next((self._widgets[k["clave"]] for k in campos if k.get("clave") in self._widgets), None)
        if primero is not None:
            primero.focus_set()

    def _celda(self, campo, valores):
        t, clave = campo["tipo"], campo.get("clave")
        celda = ctk.CTkFrame(self.cuerpo, fg_color="transparent")
        etiqueta = campo.get("etiqueta", "") + (" *" if campo.get("obligatorio") else "")
        if t == "fecha":
            etiqueta += "   (día/mes/año)"
        if t != "check":
            ctk.CTkLabel(celda, text=etiqueta, font=fuente(14, True), text_color=c("suave"),
                         anchor="w").pack(anchor="w", pady=(0, 5))

        if t == "checks":
            caja = ctk.CTkFrame(celda, fg_color="transparent")
            caja.pack(anchor="w")
            for i, (k, texto) in enumerate(campo["opciones"]):
                v = tk.IntVar(value=int(valores.get(k) or 0))
                self._vars[k] = v
                self._casilla(caja, texto, v).grid(row=i // 3, column=i % 3, sticky="w",
                                                   padx=(0, 26), pady=5)
        elif t == "check":
            v = tk.IntVar(value=int(valores.get(clave) or 0))
            self._vars[clave] = v
            self._casilla(celda, campo.get("texto", campo.get("etiqueta", "Sí")), v).pack(anchor="w")
        elif t == "combo":
            opciones = campo["opciones"]() if callable(campo["opciones"]) else list(campo["opciones"])
            vacio = campo.get("vacio", "")
            actual = valores.get(clave) or (opciones[0] if campo.get("primero") and opciones else vacio)
            if actual and actual != vacio and actual not in opciones:
                opciones.append(actual)
            if campo.get("incluir_vacio") and vacio:
                opciones = [vacio] + opciones
            v = tk.StringVar(value=actual)
            w = ctk.CTkComboBox(celda, values=opciones or [""], variable=v, state="readonly",
                                height=44, corner_radius=10, font=fuente(16),
                                dropdown_font=fuente(16), fg_color=c("tarjeta2"),
                                border_color=c("borde"), button_color=c("borde"),
                                button_hover_color=c("acento"), text_color=c("texto"),
                                dropdown_fg_color=c("tarjeta"), dropdown_text_color=c("texto"),
                                dropdown_hover_color=c("hover"))
            w.pack(fill="x")
            self._vars[clave], self._widgets[clave] = v, w
        elif t == "fecha":
            inicial = fechas.formatear(valores.get(clave)) if valores.get(clave) else (
                date.today().strftime("%d/%m/%Y") if campo.get("hoy") else "")
            v = tk.StringVar(value=inicial)
            fila = ctk.CTkFrame(celda, fg_color="transparent")
            fila.pack(fill="x")
            boton(fila, "Hoy", lambda var=v: var.set(date.today().strftime("%d/%m/%Y")),
                  "secundario", 64, 44, 14).pack(side="right", padx=(8, 0))
            w = _entrada(fila, textvariable=v)
            w.pack(side="left", fill="x", expand=True)
            self._vars[clave], self._widgets[clave] = v, w
        else:  # texto, dinero, entero
            valor = valores.get(clave)
            if t == "dinero":
                valor = str(int(valor)) if valor else ""
            v = tk.StringVar(value="" if valor is None else str(valor))
            w = _entrada(celda, textvariable=v)
            w.pack(fill="x")
            self._vars[clave], self._widgets[clave] = v, w
        return celda

    @staticmethod
    def _casilla(padre, texto, variable):
        return ctk.CTkCheckBox(padre, text=texto, variable=variable, font=fuente(16),
                               text_color=c("texto"), fg_color=c("acento"),
                               hover_color=c("acento_hover"), border_color=c("suave"),
                               checkmark_color=c("sobre_acento"), checkbox_width=24,
                               checkbox_height=24, corner_radius=7, border_width=2)

    def _error(self, mensaje, clave=None):
        self.lbl_error.configure(text="⚠  " + mensaje)
        if clave in self._widgets:
            self._widgets[clave].focus_set()

    def _guardar(self):
        self.lbl_error.configure(text="")
        datos = {}
        for campo in self._campos:
            tipo, clave, etiqueta = campo["tipo"], campo.get("clave"), campo.get("etiqueta", "")
            if tipo == "checks":
                for k, _ in campo["opciones"]:
                    datos[k] = self._vars[k].get()
                continue
            if tipo == "check":
                datos[clave] = self._vars[clave].get()
                continue
            texto = self._vars[clave].get().strip()
            if tipo == "combo" and campo.get("vacio") and texto == campo["vacio"]:
                texto = ""
            if campo.get("obligatorio") and not texto:
                return self._error(f"Falta llenar: {etiqueta}", clave)
            if tipo == "fecha":
                if texto:
                    try:
                        datos[clave] = fechas.parsear(texto).isoformat()
                    except ValueError:
                        return self._error(f"Fecha no válida en «{etiqueta}». Ejemplo: 25/12/2026", clave)
                else:
                    datos[clave] = None
            elif tipo == "dinero":
                limpio = texto.replace(".", "").replace(",", "").replace("$", "").replace(" ", "")
                if limpio and not limpio.isdigit():
                    return self._error(f"«{etiqueta}» debe tener solo números (en pesos).", clave)
                datos[clave] = int(limpio or 0)
            elif tipo == "entero":
                try:
                    n = int(texto)
                except ValueError:
                    return self._error(f"«{etiqueta}» debe ser un número entero.", clave)
                if not campo.get("min", 0) <= n <= campo.get("max", 10 ** 6):
                    return self._error(f"«{etiqueta}» debe estar entre {campo.get('min', 0)} y "
                                       f"{campo.get('max', 10 ** 6)}.", clave)
                datos[clave] = n
            else:
                datos[clave] = texto.upper() if campo.get("mayusculas") else texto
        if self._validar:
            problema = self._validar(datos)
            if problema:
                return self._error(problema)
        self.resultado = datos
        self.destroy()

    @classmethod
    def pedir(cls, padre, titulo, campos, valores=None, subtitulo="Los campos con * son obligatorios.",
              validar=None):
        ventana = cls(padre, titulo, campos, valores, subtitulo, validar)
        padre.wait_window(ventana)
        return ventana.resultado
