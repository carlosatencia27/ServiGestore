"""Tabla con filas de tarjeta: persona con avatar, pastillas de estado, acciones y paginación."""
import math

import customtkinter as ctk

from .. import config
from .componentes import avatar, boton, corto, iniciales, pastilla
from .tema import c, fuente

ALTO_FILA = 58
ALTO_CABECERA = 44
ALTO_PIE = 62


class _Fila:
    def __init__(self, tabla, padre):
        self.tabla = tabla
        self.id = None
        self.cont = ctk.CTkFrame(padre, fg_color="transparent", corner_radius=10, height=ALTO_FILA)
        self.cont.grid_propagate(False)
        self.cont.grid_rowconfigure(0, weight=1)
        tabla.configurar_columnas(self.cont)
        self.sep = ctk.CTkFrame(padre, height=1, fg_color=c("borde"), corner_radius=0)
        self.celdas = []
        for i, col in enumerate(tabla.columnas):
            tipo = col["tipo"]
            cel = ctk.CTkFrame(self.cont, fg_color="transparent", width=1, height=ALTO_FILA)
            cel.grid(row=0, column=i, sticky="nsew")
            cel.pack_propagate(False)
            izq = 14 if i == 0 else 6
            if tipo in ("texto", "negrita"):
                w = ctk.CTkLabel(cel, text="", anchor="w", font=fuente(config.TAMANO_TABLA, tipo == "negrita"),
                                 text_color=c("texto"))
                w.pack(side="left", padx=(izq, 0))
                self.celdas.append(w)
            elif tipo == "persona":
                caja = ctk.CTkFrame(cel, fg_color="transparent")
                caja.pack(side="left", padx=(izq, 0))
                av = avatar(caja, "", 40)
                av.grid(row=0, column=0, rowspan=2, padx=(0, 12))
                n = ctk.CTkLabel(caja, text="", anchor="w", font=fuente(config.TAMANO_TABLA, True),
                                 text_color=c("texto"))
                n.grid(row=0, column=1, sticky="sw")
                s = ctk.CTkLabel(caja, text="", anchor="w", font=fuente(13), text_color=c("suave"))
                s.grid(row=1, column=1, sticky="nw")
                self.celdas.append((av, n, s))
            elif tipo == "doble":
                caja = ctk.CTkFrame(cel, fg_color="transparent")
                caja.pack(side="left", padx=(izq, 0))
                a = ctk.CTkLabel(caja, text="", anchor="w", font=fuente(config.TAMANO_TABLA),
                                 text_color=c("texto"))
                a.pack(anchor="w")
                b = ctk.CTkLabel(caja, text="", anchor="w", font=fuente(13), text_color=c("suave"))
                self.celdas.append((a, b))
            elif tipo == "pastilla":
                w = pastilla(cel, "", "neutro")
                w.pack(side="left", padx=(izq, 0))
                self.celdas.append(w)
            elif tipo == "acciones":
                botones = []
                for texto, estilo, cb in reversed(col["acciones"]):
                    b = boton(cel, texto, lambda cb=cb: cb(self.id), estilo, 26 + 9 * len(texto), 34, 14)
                    b.pack(side="right", padx=(0, 4))
                    botones.append(b)
                self.celdas.append(botones)
        self._enlazar_hover()

    def _enlazar_hover(self):
        def entra(ev=None):
            self.cont.configure(fg_color=c("hover"))

        def sale(ev=None):
            self.cont.configure(fg_color="transparent")
        def recorrer(w):
            w.bind("<Enter>", entra, add="+")
            w.bind("<Leave>", sale, add="+")
            for h in w.winfo_children():
                recorrer(h)
        recorrer(self.cont)

    def poner(self, fila):
        self.id = fila["id"]
        for col, celda in zip(self.tabla.columnas, self.celdas):
            tipo, valor = col["tipo"], fila["celdas"].get(col["clave"])
            maximo = col.get("maximo", 40)
            if tipo in ("texto", "negrita"):
                celda.configure(text=corto(valor, maximo))
            elif tipo == "persona":
                nombre, sub = valor
                av, n, s = celda
                av.configure(text=iniciales(nombre))
                n.configure(text=corto(nombre, maximo))
                s.configure(text=corto(sub, maximo + 4))
            elif tipo == "doble":
                principal, segundo = valor
                a, b = celda
                a.configure(text=corto(principal, maximo))
                b.configure(text=corto(segundo, maximo))
                if segundo:
                    b.pack(anchor="w")
                else:
                    b.pack_forget()
            elif tipo == "pastilla":
                texto, tono = valor
                celda.configure(text=f"  {texto}  ", fg_color=c(tono + "_bg"), text_color=c(tono))
                if texto:
                    celda.pack(side="left", padx=(6, 0))
                else:
                    celda.pack_forget()

    def mostrar(self):
        self.cont.pack(fill="x", padx=14)
        self.sep.pack(fill="x", padx=22)

    def ocultar(self):
        self.cont.pack_forget()
        self.sep.pack_forget()


class Tabla(ctk.CTkFrame):
    """columnas: [{clave, titulo, peso, tipo, maximo?, acciones?}]
    tipos: texto | negrita | persona | pastilla | acciones"""

    def __init__(self, padre, columnas, vacio="", **kw):
        super().__init__(padre, fg_color=c("tarjeta"), corner_radius=16, border_width=1,
                         border_color=c("borde"), **kw)
        self.pack_propagate(False)
        self.columnas, self.vacio_texto = columnas, vacio
        self.filas, self.pie_extra = [], ""
        self.pagina, self.por_pagina = 0, 5
        self._pool = []
        self._ultimo_alto = 0

        self.cabecera = ctk.CTkFrame(self, fg_color=c("tarjeta2"), corner_radius=10,
                                     height=ALTO_CABECERA)
        self.cabecera.pack(fill="x", padx=14, pady=(14, 4))
        self.cabecera.grid_propagate(False)
        self.cabecera.grid_rowconfigure(0, weight=1)
        self.configurar_columnas(self.cabecera)
        for i, col in enumerate(columnas):
            ctk.CTkLabel(self.cabecera, text=col["titulo"], anchor="w", width=10,
                         font=fuente(13, True), text_color=c("suave")).grid(
                row=0, column=i, sticky="ew", padx=(14 if i == 0 else 6, 6))

        self.pie = ctk.CTkFrame(self, fg_color="transparent", height=ALTO_PIE)
        self.pie.pack(side="bottom", fill="x", padx=18)
        self.pie.pack_propagate(False)
        self.info = ctk.CTkLabel(self.pie, text="", font=fuente(14), text_color=c("suave"), anchor="w")
        self.info.pack(side="left")
        self.b_sig = boton(self.pie, "›", self.siguiente, "secundario", 40, 36, 18)
        self.b_sig.pack(side="right")
        self.lbl_pag = ctk.CTkLabel(self.pie, text="", font=fuente(14), text_color=c("suave"), width=110)
        self.lbl_pag.pack(side="right", padx=6)
        self.b_ant = boton(self.pie, "‹", self.anterior, "secundario", 40, 36, 18)
        self.b_ant.pack(side="right")

        self.cuerpo = ctk.CTkFrame(self, fg_color="transparent")
        self.cuerpo.pack(fill="both", expand=True)
        self.vacio = ctk.CTkLabel(self.cuerpo, text="", font=fuente(17), text_color=c("suave"),
                                  justify="center")
        self.bind("<Configure>", self._al_cambiar_tamano)

    def configurar_columnas(self, marco):
        for i, col in enumerate(self.columnas):
            marco.grid_columnconfigure(i, weight=int(round(col["peso"] * 10)), uniform="col")

    # ---- tamaño: cuántas filas caben ----
    def _al_cambiar_tamano(self, ev):
        if abs(ev.height - self._ultimo_alto) < 4:
            return
        self._ultimo_alto = ev.height
        libre = ev.height - 14 - ALTO_CABECERA - 4 - ALTO_PIE - 10
        n = max(3, min(30, libre // (ALTO_FILA + 1)))
        if n != self.por_pagina:
            self.por_pagina = n
            self.after_idle(self._dibujar)

    def _asegurar(self, n):
        while len(self._pool) < n:
            self._pool.append(_Fila(self, self.cuerpo))

    # ---- datos ----
    def mostrar(self, filas, pie_extra="", volver_inicio=True):
        """filas: [{id, celdas: {clave: valor}}]"""
        self.filas, self.pie_extra = filas, pie_extra
        if volver_inicio:
            self.pagina = 0
        self._dibujar()

    def _dibujar(self):
        total = len(self.filas)
        paginas = max(1, math.ceil(total / self.por_pagina))
        self.pagina = max(0, min(self.pagina, paginas - 1))
        ini = self.pagina * self.por_pagina
        visibles = self.filas[ini:ini + self.por_pagina]
        self._asegurar(len(visibles))
        for f in self._pool:
            f.ocultar()
        for f, datos in zip(self._pool, visibles):
            f.poner(datos)
            f.mostrar()
        if total:
            self.vacio.place_forget()
            texto = f"Mostrando {ini + 1}–{ini + len(visibles)} de {total}"
        else:
            self.vacio.configure(text=self.vacio_texto)
            self.vacio.place(relx=0.5, rely=0.42, anchor="center")
            texto = "0 registros"
        if self.pie_extra:
            texto += f"     ·     {self.pie_extra}"
        self.info.configure(text=texto)
        self.lbl_pag.configure(text=f"Página {self.pagina + 1} de {paginas}")
        self.b_ant.configure(state="normal" if self.pagina > 0 else "disabled")
        self.b_sig.configure(state="normal" if self.pagina < paginas - 1 else "disabled")

    def anterior(self):
        self.pagina -= 1
        self._dibujar()

    def siguiente(self):
        self.pagina += 1
        self._dibujar()
