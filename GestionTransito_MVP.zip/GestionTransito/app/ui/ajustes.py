"""Ventanas de ajustes y de categorías."""
import customtkinter as ctk

from .. import config, vencimientos
from ..repositorio import (agregar_categoria, editar_categoria, eliminar_categoria, guardar_ajuste,
                           listar_categorias_detalle, obtener_ajuste)
from .componentes import VentanaModal, boton, confirmar, informar
from .formulario import Formulario
from .tema import c, fuente

CAMPOS_CATEGORIA = [
    {"clave": "codigo", "etiqueta": "Nombre de la categoría", "tipo": "texto", "obligatorio": True,
     "mayusculas": True},
    {"clave": "anios", "etiqueta": "Años de vigencia", "tipo": "entero", "obligatorio": True,
     "min": 1, "max": 50},
]


class DialogoCategorias(VentanaModal):
    def __init__(self, app, con):
        super().__init__(app, "Categorías de licencia",
                         "Cada categoría tiene sus años de vigencia. Edite la lista a su gusto.", ancho=560)
        self.app, self.con = app, con
        self.lista = ctk.CTkScrollableFrame(self.cuerpo, fg_color=c("tarjeta2"), corner_radius=12,
                                            height=300, width=480)
        self.lista.pack(fill="x")
        boton(self.pie, "Agregar categoría", self.agregar, "primario", 190, 44).pack(side="left")
        boton(self.pie, "Cerrar", self.destroy, "secundario", 110, 44).pack(side="right")
        self.recargar()
        self.abrir()

    def recargar(self):
        for w in self.lista.winfo_children():
            w.destroy()
        for cat in listar_categorias_detalle(self.con):
            fila = ctk.CTkFrame(self.lista, fg_color="transparent")
            fila.pack(fill="x", pady=2)
            ctk.CTkLabel(fila, text=cat["codigo"], font=fuente(17, True), text_color=c("texto"),
                         anchor="w", width=60).pack(side="left", padx=(12, 0))
            anios = cat["anios"]
            ctk.CTkLabel(fila, text=f"{anios} año" if anios == 1 else f"{anios} años", font=fuente(15),
                         text_color=c("suave"), anchor="w").pack(side="left", padx=10)
            boton(fila, "Quitar", lambda x=cat["codigo"]: self.quitar(x), "peligro", 80, 34, 14).pack(side="right")
            boton(fila, "Editar", lambda x=cat: self.editar(x), "fantasma", 80, 34, 14).pack(side="right")

    def agregar(self):
        datos = Formulario.pedir(self, "Agregar categoría", CAMPOS_CATEGORIA, {"anios": 10},
                                 "Ejemplo: nombre A1, 10 años.")
        if datos is None:
            return
        try:
            agregar_categoria(self.con, datos["codigo"], datos["anios"])
        except ValueError as ex:
            informar(self, "No se pudo agregar", str(ex))
        self.recargar()

    def editar(self, cat):
        datos = Formulario.pedir(self, "Editar categoría", CAMPOS_CATEGORIA,
                                 {"codigo": cat["codigo"], "anios": cat["anios"]},
                                 "Si cambia los años, se recalculan los vencimientos ya guardados.")
        if datos is None:
            return
        try:
            editar_categoria(self.con, cat["codigo"], datos["codigo"], datos["anios"])
        except ValueError as ex:
            return informar(self, "No se pudo cambiar", str(ex))
        if datos["anios"] != cat["anios"]:
            vencimientos.recalcular_licencias(self.con)
        self.recargar()
        self.app.al_cambiar(recargar_todo=True)

    def quitar(self, codigo):
        if confirmar(self, "Quitar categoría",
                     f"¿Quitar {codigo} de la lista?\n\nLos registros ya guardados no se borran.", "Quitar"):
            eliminar_categoria(self.con, codigo)
            self.recargar()


def abrir_ajustes(app):
    con = app.con
    valores = {
        "dias_aviso": obtener_ajuste(con, "dias_aviso", config.DIAS_AVISO_DEFECTO),
        "vigencia_seguro_meses": obtener_ajuste(con, "vigencia_seguro_meses",
                                                config.VIGENCIA_SEGURO_MESES_DEFECTO),
        "vigencia_tecno_meses": obtener_ajuste(con, "vigencia_tecno_meses",
                                               config.VIGENCIA_TECNO_MESES_DEFECTO),
        "tema": "Oscuro" if obtener_ajuste(con, "tema", "dark") == "dark" else "Claro",
    }
    campos = [
        {"clave": "dias_aviso", "etiqueta": "Días de aviso antes de vencer", "tipo": "entero",
         "obligatorio": True, "min": 1, "max": 365},
        {"clave": "vigencia_seguro_meses", "etiqueta": "Vigencia del seguro (meses)",
         "tipo": "entero", "obligatorio": True, "min": 1, "max": 120},
        {"clave": "vigencia_tecno_meses", "etiqueta": "Vigencia de la tecnomecánica (meses)",
         "tipo": "entero", "obligatorio": True, "min": 1, "max": 120},
        {"clave": "tema", "etiqueta": "Apariencia", "tipo": "combo", "opciones": ["Oscuro", "Claro"]},
    ]
    datos = Formulario.pedir(app, "Ajustes", campos, valores, "Cambie los avisos, las vigencias y la apariencia.")
    if datos is None:
        return
    guardar_ajuste(con, "dias_aviso", datos["dias_aviso"])
    if str(datos["vigencia_seguro_meses"]) != str(valores["vigencia_seguro_meses"]):
        guardar_ajuste(con, "vigencia_seguro_meses", datos["vigencia_seguro_meses"])
        vencimientos.recalcular_seguros(con, datos["vigencia_seguro_meses"])
    if str(datos["vigencia_tecno_meses"]) != str(valores["vigencia_tecno_meses"]):
        guardar_ajuste(con, "vigencia_tecno_meses", datos["vigencia_tecno_meses"])
        vencimientos.recalcular_tecnomecanicas(con, datos["vigencia_tecno_meses"])
    app.aplicar_tema("dark" if datos["tema"] == "Oscuro" else "light")
    app.al_cambiar(recargar_todo=True)
