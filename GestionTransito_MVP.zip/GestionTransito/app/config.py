"""Configuración general. Aquí se cambian vigencias, letra y textos básicos."""
import os
import sys


def carpeta_app():
    """Carpeta donde está el programa (junto al .exe, o la carpeta del proyecto)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


CARPETA_DATOS = os.path.join(carpeta_app(), "datos")
RUTA_DB = os.path.join(CARPETA_DATOS, "transito.db")

TITULO_APP = "Gestión de Trámites de Tránsito"

# Vigencia de la licencia (años) según el tipo, contada desde la fecha en que se realizó.
VIGENCIA_LICENCIA_ANIOS = {"PÚBLICO": 3, "PARTICULAR": 10, "MOTO": 10}
TIPOS_LICENCIA = list(VIGENCIA_LICENCIA_ANIOS)

# Categorías iniciales con sus años de vigencia (la lista se edita dentro del programa).
# A2 = moto, B1 = carro particular (10 años); C1, C2 y C3 = servicio público (3 años).
CATEGORIAS_INICIALES = [("A2", 10), ("B1", 10), ("C1", 3), ("C2", 3), ("C3", 3)]
CATEGORIA_TIPO = {"A2": "MOTO", "B1": "PARTICULAR", "C1": "PÚBLICO", "C2": "PÚBLICO", "C3": "PÚBLICO"}

# Valores iniciales de los ajustes (se pueden cambiar dentro del programa).
DIAS_AVISO_DEFECTO = 30
VIGENCIA_SEGURO_MESES_DEFECTO = 12
VIGENCIA_TECNO_MESES_DEFECTO = 12

FUENTE = "Segoe UI"
TAMANO = 16          # letra general (px)
TAMANO_TABLA = 15    # letra dentro de las tablas (px)
