"""Cálculo de fechas de vencimiento y lista de próximos vencimientos."""
from datetime import date, timedelta

from . import config
from .fechas import de_iso, sumar_anios, sumar_meses, texto_dias


def vencimiento_licencia(tipo, fecha):
    """PÚBLICO = 3 años, PARTICULAR = 10, MOTO = 10, desde la fecha en que se realizó."""
    return sumar_anios(fecha, config.VIGENCIA_LICENCIA_ANIOS[tipo])


def vencimiento_seguro(fecha_inicio, meses):
    return sumar_meses(fecha_inicio, meses)


def anios_categoria(con, categoria, tipo_respaldo=None):
    """Años de vigencia de una categoría (A2 y B1 = 10, C1/C2/C3 = 3 por defecto).
    Si la categoría ya no está en la lista, usa el tipo guardado en el registro."""
    fila = con.execute("SELECT anios FROM categorias WHERE codigo = ?", (categoria,)).fetchone()
    if fila:
        return fila["anios"]
    return config.VIGENCIA_LICENCIA_ANIOS.get(tipo_respaldo, 10)


def vencimiento_por_categorias(con, categorias, fecha, tipo_respaldo=None):
    """Con dos categorías, vale la fecha que llega primero (la que primero hay que renovar)."""
    cats = [c for c in categorias if c]
    return min(sumar_anios(fecha, anios_categoria(con, c, tipo_respaldo)) for c in cats)


def tipo_de_categoria(categoria, respaldo=None):
    return config.CATEGORIA_TIPO.get(categoria, respaldo or "")


def texto_categorias(fila):
    cats = [c for c in (fila["categoria"], fila["categoria2"]) if c]
    return " + ".join(cats)


def estado(fecha_iso, dias_aviso, hoy=None):
    """Texto de estado: VENCIDO / VENCE HOY / Vence en N días / Vigente."""
    if not fecha_iso:
        return ""
    hoy = hoy or date.today()
    d = (de_iso(fecha_iso) - hoy).days
    if d < 0:
        return f"VENCIDO hace {texto_dias(-d)}"
    if d == 0:
        return "VENCE HOY"
    if d <= dias_aviso:
        return f"Vence en {texto_dias(d)}"
    return "Vigente"


def requiere_aviso(fecha_iso, dias_aviso, hoy=None):
    if not fecha_iso:
        return False
    hoy = hoy or date.today()
    return (de_iso(fecha_iso) - hoy).days <= dias_aviso


def _fila(seccion, clave, r, detalle, dias_aviso, hoy):
    return {
        "seccion": seccion, "clave": clave, "nombre": r["nombre"], "cedula": r["cedula"],
        "telefono": r["telefono"] or "", "detalle": detalle,
        "vence": de_iso(r["fecha_vencimiento"]),
        "estado": estado(r["fecha_vencimiento"], dias_aviso, hoy),
    }


# (tabla, nombre de la sección, página de la app, cómo describir el documento)
FUENTES = [
    ("expediciones", "Expedición", "expediciones", lambda r: texto_categorias(r)),
    ("licencias", "Refrendación", "licencias", lambda r: texto_categorias(r)),
    ("seguros", "Seguro", "seguro", lambda r: r["placa"]),
    ("tecnomecanicas", "Tecnomecánica", "tecnomecanica", lambda r: r["placa"]),
]


def proximos(con, dias_aviso, hoy=None):
    """Registros ya vencidos o que vencen dentro de 'dias_aviso' días, del más urgente al menos."""
    hoy = hoy or date.today()
    limite = (hoy + timedelta(days=dias_aviso)).isoformat()
    filas = []
    for tabla, seccion, clave, detalle in FUENTES:
        for r in con.execute(f"SELECT * FROM {tabla} WHERE fecha_vencimiento <= ?", (limite,)):
            filas.append(_fila(seccion, clave, r, detalle(r), dias_aviso, hoy))
    filas.sort(key=lambda f: f["vence"])
    return filas


def _recalcular_meses(con, tabla, meses):
    for r in con.execute(f"SELECT id, fecha_inicio FROM {tabla}").fetchall():
        nuevo = sumar_meses(de_iso(r["fecha_inicio"]), meses).isoformat()
        con.execute(f"UPDATE {tabla} SET fecha_vencimiento = ? WHERE id = ?", (nuevo, r["id"]))
    con.commit()


def recalcular_seguros(con, meses):
    """Si cambia la vigencia del seguro en Ajustes, se recalculan los existentes."""
    _recalcular_meses(con, "seguros", meses)


def recalcular_tecnomecanicas(con, meses):
    _recalcular_meses(con, "tecnomecanicas", meses)


def recalcular_licencias(con):
    """Si cambian los años de una categoría, se recalculan las licencias existentes."""
    for tabla in ("licencias", "expediciones"):
        for r in con.execute(f"SELECT id, tipo, categoria, categoria2, fecha_realizada FROM {tabla}").fetchall():
            nuevo = vencimiento_por_categorias(con, [r["categoria"], r["categoria2"]],
                                               de_iso(r["fecha_realizada"]), r["tipo"]).isoformat()
            con.execute(f"UPDATE {tabla} SET fecha_vencimiento = ? WHERE id = ?", (nuevo, r["id"]))
    con.commit()


def estado_visual(texto):
    """Agrega un símbolo al estado para que se entienda de un vistazo (sin colores)."""
    if texto.startswith(("VENCIDO", "VENCE HOY")):
        return "■  " + texto
    if texto.startswith("Vence"):
        return "▲  " + texto
    if texto == "Vigente":
        return "✓  Vigente"
    return texto


def estado_pastilla(fecha_iso, dias_aviso, hoy=None):
    """(texto corto, tono) para la pastilla de estado. tono: peligro | aviso | ok."""
    from .fechas import humanizar_dias
    if not fecha_iso:
        return ("", "neutro")
    hoy = hoy or date.today()
    d = (de_iso(fecha_iso) - hoy).days
    if d < 0:
        return (f"Vencido hace {humanizar_dias(-d)}", "peligro")
    if d == 0:
        return ("Vence hoy", "peligro")
    if d <= dias_aviso:
        return (f"Vence en {humanizar_dias(d)}", "aviso")
    return ("Vigente", "ok")
