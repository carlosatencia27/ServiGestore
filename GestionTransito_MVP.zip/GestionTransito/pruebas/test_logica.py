import unittest
from datetime import date

from app import base_datos, vencimientos
from app.fechas import parsear, sumar_anios, sumar_meses
from app.repositorio import (Repositorio, agregar_categoria, listar_categorias)


class PruebasFechas(unittest.TestCase):
    def test_parsear(self):
        self.assertEqual(parsear("5/3/2026"), date(2026, 3, 5))
        self.assertEqual(parsear("05-03-2026"), date(2026, 3, 5))
        with self.assertRaises(ValueError):
            parsear("31/02/2026")

    def test_anios_bisiesto(self):
        self.assertEqual(sumar_anios(date(2024, 2, 29), 3), date(2027, 2, 28))
        self.assertEqual(sumar_meses(date(2026, 1, 31), 1), date(2026, 2, 28))

    def test_vigencias_licencia(self):
        f = date(2026, 5, 10)
        self.assertEqual(vencimientos.vencimiento_licencia("PÚBLICO", f), date(2029, 5, 10))
        self.assertEqual(vencimientos.vencimiento_licencia("PARTICULAR", f), date(2036, 5, 10))
        self.assertEqual(vencimientos.vencimiento_licencia("MOTO", f), date(2036, 5, 10))


class PruebasBase(unittest.TestCase):
    def setUp(self):
        self.con = base_datos.conectar(":memory:")

    def _lic(self):
        def derivar(d, previo=None):
            d["fecha_vencimiento"] = vencimientos.vencimiento_licencia(
                d["tipo"], date.fromisoformat(d["fecha_realizada"])).isoformat()
            return d
        return Repositorio(self.con, "licencias", ["nombre", "cedula", "telefono", "tipo",
                           "categoria", "fecha_realizada", "fecha_vencimiento"], derivar)

    def test_crud_y_busqueda(self):
        r = self._lic()
        id_ = r.insertar({"nombre": "José Muñoz", "cedula": "123", "telefono": "300",
                          "tipo": "PÚBLICO", "categoria": "C1", "fecha_realizada": "2026-01-15"})
        self.assertEqual(r.obtener(id_)["fecha_vencimiento"], "2029-01-15")
        self.assertEqual(len(r.listar("munoz")), 1)      # sin tildes ni ñ
        self.assertEqual(len(r.listar("123")), 1)
        self.assertEqual(len(r.listar("zzz")), 0)
        r.actualizar(id_, {"nombre": "José Muñoz", "cedula": "123", "telefono": "300",
                           "tipo": "MOTO", "categoria": "A2", "fecha_realizada": "2026-01-15"})
        self.assertEqual(r.obtener(id_)["fecha_vencimiento"], "2036-01-15")
        r.eliminar(id_)
        self.assertEqual(len(r.listar()), 0)

    def test_proximos(self):
        r = self._lic()
        base = {"cedula": "1", "telefono": "", "categoria": "B1", "tipo": "PÚBLICO"}
        r.insertar({**base, "nombre": "Vencido", "fecha_realizada": "2022-01-01"})   # vence 2025
        r.insertar({**base, "nombre": "Pronto", "fecha_realizada": "2023-11-20"})    # vence 2026-11-20
        r.insertar({**base, "nombre": "Lejos", "fecha_realizada": "2026-01-01"})
        hoy = date(2026, 10, 25)
        res = vencimientos.proximos(self.con, 30, hoy)
        self.assertEqual([f["nombre"] for f in res], ["Vencido", "Pronto"])
        self.assertTrue(res[0]["estado"].startswith("VENCIDO"))
        self.assertEqual(vencimientos.proximos(self.con, 10, hoy)[-1]["nombre"], "Vencido")

    def test_categorias(self):
        self.assertIn("B1", listar_categorias(self.con))
        agregar_categoria(self.con, " d1 ")
        self.assertIn("D1", listar_categorias(self.con))
        with self.assertRaises(ValueError):
            agregar_categoria(self.con, "D1")


class PruebasEstadisticas(unittest.TestCase):
    def setUp(self):
        self.con = base_datos.conectar(":memory:")

    def test_resumen_y_meses(self):
        from app import estadisticas
        hoy = date(2026, 10, 15)
        for f, v in (("2026-10-02", 100000), ("2026-10-10", 50000), ("2026-09-20", 100000), ("2026-07-01", 30000)):
            self.con.execute("INSERT INTO tramites (nombre, cedula, placa, fecha_entrega, valor) VALUES ('a','1','X',?,?)", (f, v))
        self.con.execute("INSERT INTO licencias (nombre, cedula, tipo, categoria, fecha_realizada, fecha_vencimiento) VALUES ('a','1','MOTO','A2','2013-01-01','2023-01-01')")
        self.con.execute("INSERT INTO licencias (nombre, cedula, tipo, categoria, fecha_realizada, fecha_vencimiento) VALUES ('b','2','MOTO','A2','2016-11-01','2026-11-01')")
        self.con.execute("INSERT INTO seguros (nombre, cedula, placa, fecha_inicio, fecha_vencimiento) VALUES ('c','3','X','2026-01-01','2027-01-01')")
        r = estadisticas.resumen(self.con, 30, hoy)
        self.assertEqual((r["vencidos"], r["por_vencer"], r["documentos"]), (1, 1, 3))
        self.assertEqual(r["porcentaje_al_dia"], 33)
        self.assertEqual((r["tramites_mes"], r["ingresos_mes"]), (2, 150000))
        self.assertEqual(r["ingresos_var"], 50)
        meses = estadisticas.tramites_por_mes(self.con, 6, hoy)
        self.assertEqual([m[0] for m in meses], ["may", "jun", "jul", "ago", "sep", "oct"])
        self.assertEqual([m[1] for m in meses], [0, 0, 1, 0, 1, 2])

    def test_pastilla(self):
        hoy = date(2026, 10, 15)
        self.assertEqual(vencimientos.estado_pastilla("2026-10-10", 30, hoy)[1], "peligro")
        self.assertEqual(vencimientos.estado_pastilla("2026-10-25", 30, hoy)[1], "aviso")
        self.assertEqual(vencimientos.estado_pastilla("2027-10-25", 30, hoy), ("Vigente", "ok"))


class PruebasNuevas(unittest.TestCase):
    def test_categorias_y_vigencias(self):
        con = base_datos.conectar(":memory:")
        self.assertEqual(listar_categorias(con), ["A2", "B1", "C1", "C2", "C3"])
        f = date(2026, 5, 10)
        v = vencimientos.vencimiento_por_categorias
        self.assertEqual(v(con, ["A2", ""], f), date(2036, 5, 10))
        self.assertEqual(v(con, ["B1", None], f), date(2036, 5, 10))
        for c in ("C1", "C2", "C3"):
            self.assertEqual(v(con, [c, ""], f), date(2029, 5, 10))
        # con dos categorías vale la que vence primero
        self.assertEqual(v(con, ["B1", "C1"], f), date(2029, 5, 10))
        # categoría que ya no está en la lista: usa el tipo guardado
        self.assertEqual(v(con, ["B2", ""], f, "PÚBLICO"), date(2029, 5, 10))

    def test_editar_categoria_y_recalcular(self):
        from app.repositorio import editar_categoria
        con = base_datos.conectar(":memory:")
        con.execute("INSERT INTO expediciones (nombre, cedula, tipo, categoria, categoria2, fecha_realizada, fecha_vencimiento) "
                    "VALUES ('a','1','','C1','B1','2026-01-01','2029-01-01')")
        editar_categoria(con, "C1", "C9", 5)
        vencimientos.recalcular_licencias(con)
        fila = con.execute("SELECT * FROM expediciones").fetchone()
        self.assertEqual((fila["categoria"], fila["fecha_vencimiento"]), ("C9", "2031-01-01"))

    def test_migracion_base_antigua(self):
        import os, sqlite3, tempfile
        ruta = os.path.join(tempfile.mkdtemp(), "vieja.db")
        v = sqlite3.connect(ruta)
        v.executescript("""
            CREATE TABLE categorias (id INTEGER PRIMARY KEY AUTOINCREMENT, codigo TEXT NOT NULL UNIQUE);
            CREATE TABLE ajustes (clave TEXT PRIMARY KEY, valor TEXT NOT NULL);
            CREATE TABLE licencias (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, cedula TEXT NOT NULL,
                telefono TEXT, tipo TEXT NOT NULL, categoria TEXT NOT NULL, fecha_realizada TEXT NOT NULL,
                fecha_vencimiento TEXT NOT NULL);
            CREATE TABLE tramites (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, cedula TEXT NOT NULL,
                telefono TEXT, placa TEXT NOT NULL, transito INTEGER NOT NULL DEFAULT 0, traspaso INTEGER NOT NULL DEFAULT 0,
                traslado INTEGER NOT NULL DEFAULT 0, duplicado INTEGER NOT NULL DEFAULT 0,
                duplicado_tarjeta INTEGER NOT NULL DEFAULT 0, nit_tarjeta_lote TEXT, fecha_entrega TEXT,
                valor INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE seguros (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, cedula TEXT NOT NULL,
                telefono TEXT, placa TEXT NOT NULL, tecnomecanica INTEGER NOT NULL DEFAULT 0,
                fecha_inicio TEXT NOT NULL, fecha_vencimiento TEXT NOT NULL);
            INSERT INTO categorias (codigo) VALUES ('A1'),('A2'),('B1'),('B2'),('B3'),('C1'),('C2'),('C3');
            INSERT INTO licencias (nombre, cedula, tipo, categoria, fecha_realizada, fecha_vencimiento)
                VALUES ('Vieja','9','PÚBLICO','C1','2024-01-01','2027-01-01');
        """)
        v.commit(); v.close()
        con = base_datos.conectar(ruta)
        self.assertEqual(listar_categorias(con), ["A2", "B1", "C1", "C2", "C3"])
        self.assertEqual(con.execute("SELECT anios FROM categorias WHERE codigo='C2'").fetchone()[0], 3)
        self.assertEqual(con.execute("SELECT anios FROM categorias WHERE codigo='B1'").fetchone()[0], 10)
        fila = con.execute("SELECT * FROM licencias").fetchone()
        self.assertEqual(fila["nombre"], "Vieja")
        self.assertIsNone(fila["telefono2"]); self.assertIsNone(fila["categoria2"])
        con.execute("SELECT * FROM expediciones"); con.execute("SELECT * FROM tecnomecanicas")
        con.close()
        con = base_datos.conectar(ruta)   # abrir otra vez no debe volver a tocar nada
        self.assertEqual(len(listar_categorias(con)), 5)

    def test_proximos_incluye_todas_las_secciones(self):
        con = base_datos.conectar(":memory:")
        con.execute("INSERT INTO expediciones (nombre, cedula, tipo, categoria, fecha_realizada, fecha_vencimiento) VALUES ('e','1','','C1','2023-10-20','2026-10-20')")
        con.execute("INSERT INTO tecnomecanicas (nombre, cedula, placa, fecha_inicio, fecha_vencimiento) VALUES ('t','2','ABC123','2025-10-20','2026-10-20')")
        r = vencimientos.proximos(con, 30, date(2026, 10, 15))
        self.assertEqual(sorted(f["clave"] for f in r), ["expediciones", "tecnomecanica"])


if __name__ == "__main__":
    unittest.main()
